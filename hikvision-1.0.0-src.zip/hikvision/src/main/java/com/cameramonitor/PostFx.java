package com.cameramonitor;

import com.cameramonitor.mixin.GameRendererAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;

/** Включает пост-эффект (шейдер) темы на время просмотра камеры. */
public final class PostFx {
    private PostFx() {}

    public static boolean apply(MinecraftClient c, String themeId) {
        if (!ModConfig.get().useShader) return false;
        try {
            ((GameRendererAccessor) (Object) c.gameRenderer)
                    .cameramonitor$setPostProcessor(Identifier.of("cameramonitor", "feed_" + themeId));
            return true;
        } catch (Throwable t) { // миксин не применился — работаем без шейдера
            return false;
        }
    }

    public static void clear(MinecraftClient c) {
        c.gameRenderer.clearPostProcessor();
    }
}
