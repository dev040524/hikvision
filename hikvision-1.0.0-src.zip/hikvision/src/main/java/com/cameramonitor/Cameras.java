package com.cameramonitor;

import com.cameramonitor.data.Model.TagMeta;
import com.cameramonitor.data.Store;
import com.cameramonitor.ui.MonitorScreen;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

import java.util.*;

/** Находит камеры в загруженном мире по названиям голов и следит за движением рядом с ними. */
public final class Cameras {
    public enum Src { BLOCK, HEAD, MAIN, OFF }

    public record Live(String tag, int index, Src src, BlockPos pos, int entityId) {
        public String key() { return tag + "#" + index; }
    }

    private static List<Live> live = List.of();
    private static final Map<String, Set<Integer>> NEAR = new HashMap<>();
    private static final Map<String, Long> MOTION = new HashMap<>();
    private static long ticks;

    private Cameras() {}

    public static List<Live> live() { return live; }

    public static Live find(String tag, int index) {
        for (Live l : live) if (l.tag().equals(tag) && l.index() == index) return l;
        return null;
    }

    public static boolean hasMotion(String tag, int index) {
        Long t = MOTION.get(tag + "#" + index);
        return t != null && t > System.currentTimeMillis();
    }

    public static boolean tagHasMotion(String tag) {
        long now = System.currentTimeMillis();
        for (var e : MOTION.entrySet()) if (e.getValue() > now && e.getKey().startsWith(tag + "#")) return true;
        return false;
    }

    public static void tick(MinecraftClient c) {
        ticks++;
        if (c.world == null || c.player == null) return;
        if (ticks % 10 == 0) {
            refresh();
            detect(c);
        }
        if (ticks % 200 == 0 && Store.isDirty()) Store.save();
    }

    public static void clear() {
        live = List.of();
        NEAR.clear();
        MOTION.clear();
    }

    // ------------------------------------------------------------------ поиск

    public static ItemStack stackOf(LivingEntity e, Src s) {
        return switch (s) {
            case HEAD -> e.getEquippedStack(EquipmentSlot.HEAD);
            case MAIN -> e.getMainHandStack();
            case OFF -> e.getOffHandStack();
            default -> ItemStack.EMPTY;
        };
    }

    /** Где сейчас у существа камера с этим тегом и номером (null — нигде). */
    public static Src srcOf(LivingEntity e, String tag, int index) {
        for (Src s : new Src[]{Src.HEAD, Src.MAIN, Src.OFF}) {
            Heads.Parsed p = Heads.parse(stackOf(e, s));
            if (p.kind() == Heads.Kind.CAMERA && p.tag().equals(tag) && p.index() == index) return s;
        }
        return null;
    }

    public static void refresh() {
        MinecraftClient c = MinecraftClient.getInstance();
        ClientWorld w = c.world;
        if (w == null || c.player == null) return;
        List<Live> out = new ArrayList<>();

        int r = Math.max(2, c.options.getClampedViewDistance());
        ChunkPos pc = c.player.getChunkPos();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                WorldChunk ch = w.getChunkManager().getWorldChunk(pc.x + dx, pc.z + dz);
                if (ch == null) continue;
                for (BlockEntity be : ch.getBlockEntities().values()) {
                    if (!(be instanceof SkullBlockEntity sk) || sk.customName == null) continue;
                    Heads.Parsed p = Heads.parse(sk.customName.getString());
                    if (p.kind() == Heads.Kind.CAMERA) out.add(new Live(p.tag(), p.index(), Src.BLOCK, be.getPos().toImmutable(), -1));
                }
            }
        }
        if (ModConfig.get().carriedCameras) {
            for (Entity e : w.getEntities()) {
                if (!(e instanceof LivingEntity le)) continue;
                for (Src s : new Src[]{Src.HEAD, Src.MAIN, Src.OFF}) {
                    Heads.Parsed p = Heads.parse(stackOf(le, s));
                    if (p.kind() == Heads.Kind.CAMERA) {
                        out.add(new Live(p.tag(), p.index(), s, null, e.getId()));
                        break;
                    }
                }
            }
        }
        live = out;
        for (Live l : out) {
            TagMeta tm = Store.get().tag(l.tag());
            if (!tm.cams.containsKey(l.index())) {
                tm.cam(l.index());
                Store.markDirty();
            }
        }
    }

    // ------------------------------------------------------------------ движение

    private static Vec3d posOf(ClientWorld w, Live l) {
        if (l.src() == Src.BLOCK) return Vec3d.ofCenter(l.pos());
        Entity e = w.getEntityById(l.entityId());
        return e == null ? null : new Vec3d(e.getX(), e.getEyeY(), e.getZ());
    }

    private static List<String> watchedTags(MinecraftClient c) {
        if (c.currentScreen instanceof MonitorScreen ms) return ms.monitorTags();
        for (ItemStack s : List.of(c.player.getMainHandStack(), c.player.getOffHandStack())) {
            Heads.Parsed p = Heads.parse(s);
            if (p.kind() == Heads.Kind.MONITOR) return Heads.splitTags(p.tag());
        }
        return null;
    }

    private static void detect(MinecraftClient c) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.motionAlerts) return;
        ClientWorld w = c.world;
        List<String> watched = watchedTags(c);
        for (Live l : live) {
            Vec3d p = posOf(w, l);
            if (p == null) continue;
            final Entity self = l.entityId() >= 0 ? w.getEntityById(l.entityId()) : null;
            Box box = new Box(p, p).expand(cfg.motionRadius);
            Set<Integer> now = new HashSet<>();
            for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, box,
                    x -> x != self && x != c.player && x.isAlive() && (cfg.motionMobs || x instanceof PlayerEntity)))
                now.add(e.getId());
            Set<Integer> prev = NEAR.put(l.key(), now);
            if (prev == null) continue;
            boolean fresh = false;
            for (int id : now) if (!prev.contains(id)) { fresh = true; break; }
            if (!fresh) continue;
            MOTION.put(l.key(), System.currentTimeMillis() + 4000);
            if (watched != null && (watched.isEmpty() || watched.contains(l.tag()))) {
                Sfx.alert();
                if (!(c.currentScreen instanceof MonitorScreen))
                    c.player.sendMessage(Text.translatable("cameramonitor.motion.alert", Heads.cameraName(l.tag(), l.index())), true);
            }
        }
    }
}
