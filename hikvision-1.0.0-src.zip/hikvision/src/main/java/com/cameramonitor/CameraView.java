package com.cameramonitor;

import net.minecraft.util.math.Vec3d;

/** Состояние «виртуальной камеры», которое применяет CameraMixin. */
public final class CameraView {
    public static final CameraView INSTANCE = new CameraView();

    private boolean active;
    private double x, y, z;
    private float yaw, pitch, zoom = 1f;

    public void set(Vec3d p, float yaw, float pitch, float zoom) {
        this.zoom = zoom;
        this.x = p.x;
        this.y = p.y;
        this.z = p.z;
        this.yaw = yaw;
        this.pitch = pitch;
        this.active = true;
    }

    public void deactivate() { active = false; }
    public boolean isActive() { return active; }
    public double x() { return x; }
    public double y() { return y; }
    public double z() { return z; }
    public float yaw() { return yaw; }
    public float pitch() { return pitch; }
    public float zoom() { return zoom; }
}
