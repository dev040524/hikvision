package com.cameramonitor.ui;

import com.cameramonitor.CameraView;
import com.cameramonitor.Cameras;
import com.cameramonitor.Heads;
import com.cameramonitor.ModConfig;
import com.cameramonitor.PostFx;
import com.cameramonitor.Sfx;
import com.cameramonitor.Signal;
import com.cameramonitor.data.Model.CamMeta;
import com.cameramonitor.data.Model.TagMeta;
import com.cameramonitor.data.Store;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.ScreenshotRecorder;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** Интерфейс монитора: «Просмотр» (живое изображение) и «Настройка» (группы, имена, порядок). */
public class MonitorScreen extends Screen {
    private enum Mode { VIEW, SETUP }
    private enum Overlay { NONE, RENAME_CAM, NEW_TAG }

    private record Entry(String tag, int idx, CamMeta meta) {}

    private static final String FAV = "\u0001fav";
    private static final int CELL = 18;

    private final List<String> monitorTags;
    private final String monitorKey;
    private Mode mode = Mode.VIEW;
    private Overlay overlay = Overlay.NONE;
    private String groupTag = "";
    private int index, listScroll;
    private int movingIdx = -1;
    private int renameIdx;
    private String renameInitial = "";
    private String confirmDelete;
    private TextFieldWidget field;
    private int nameCounter;

    private boolean enteredView, prevHud, fxApplied;
    private Perspective prevPerspective;
    private float lookYaw, lookPitch, lastDelta;
    private long lastNanos = System.nanoTime();
    private boolean prevL, prevR;
    private Signal signal;
    private boolean night, tooFar;
    private float weak;
    private long lightCheck;
    private final boolean[] prevNum = new boolean[9];
    private boolean autoCycle, shotPending;
    private long lastSwitch = System.currentTimeMillis();

    private int vx, vy, vw, vh;
    private int panelX, panelY, panelW, panelH, leftW, rightX, gridX, gridY;
    private int dx, dy, dw, dh;
    private final List<Entry> rowEntries = new ArrayList<>();
    private final List<Integer> rowYs = new ArrayList<>();
    private final List<int[]> tabRects = new ArrayList<>();
    private final List<String> tabTags = new ArrayList<>();
    private final boolean[] camSlot = new boolean[36];
    private Text status = Text.empty();
    private long statusUntil;

    public MonitorScreen(String rawTags) {
        super(Text.translatable("cameramonitor.title"));
        this.monitorTags = Heads.splitTags(rawTags);
        this.monitorKey = monitorTags.isEmpty() ? "*" : String.join(",", monitorTags);
        Cameras.refresh();
        List<String> tg = tags();
        if (tg.isEmpty()) {
            mode = Mode.SETUP;
        } else {
            groupTag = tg.get(0);
            String last = Store.get().last.get(monitorKey);
            int h = last == null ? -1 : last.lastIndexOf('#');
            if (h >= 0 && tg.contains(last.substring(0, h))) {
                groupTag = last.substring(0, h);
                if (ModConfig.get().openLastCamera) {
                    try {
                        index = Math.max(0, indexOfIdx(Integer.parseInt(last.substring(h + 1))));
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        }
    }

    private static Text t(String k, Object... a) { return Text.translatable("cameramonitor." + k, a); }

    public List<String> monitorTags() { return monitorTags; }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float d) { /* без размытия — виден мир */ }

    // ------------------------------------------------------------ данные

    private List<String> tags() {
        List<String> out = new ArrayList<>();
        if (monitorTags.isEmpty()) {
            TreeSet<String> s = new TreeSet<>(Store.get().tags.keySet());
            for (Cameras.Live l : Cameras.live()) s.add(l.tag());
            out.addAll(s);
        } else {
            out.addAll(monitorTags);
        }
        for (String d : Store.get().drafts) if (!out.contains(d)) out.add(d);
        return out;
    }

    private String tagLabel(String tag) { return tag.isEmpty() ? t("tag.none").getString() : tag; }

    private List<Entry> entries(String tag) {
        TagMeta tm = Store.get().tags.get(tag);
        TreeSet<Integer> idx = new TreeSet<>();
        if (tm != null) idx.addAll(tm.cams.keySet());
        for (Cameras.Live l : Cameras.live()) if (l.tag().equals(tag)) idx.add(l.index());
        if (idx.isEmpty()) return new ArrayList<>();
        tm = Store.get().tag(tag);
        List<Integer> order = new ArrayList<>();
        for (int i : tm.order) if (idx.remove(i)) order.add(i);
        order.addAll(idx);
        List<Entry> out = new ArrayList<>();
        for (int i : order) {
            CamMeta m = tm.cam(i);
            if (!m.hidden) out.add(new Entry(tag, i, m));
        }
        return out;
    }

    private List<Entry> list() {
        return FAV.equals(groupTag) ? favorites() : entries(groupTag);
    }

    /** Избранные камеры этого монитора: порядок задаёт номера закладок 1–9. */
    private List<Entry> favorites() {
        List<Entry> r = new ArrayList<>();
        for (String tg : tags()) for (Entry e : entries(tg)) if (e.meta().favorite) r.add(e);
        return r;
    }

    private int favNo(Entry e) {
        List<Entry> f = favorites();
        for (int i = 0; i < f.size(); i++) if (f.get(i).tag().equals(e.tag()) && f.get(i).idx() == e.idx()) return i + 1;
        return 0;
    }

    private void jumpFav(int n) {
        List<Entry> f = favorites();
        if (n >= f.size()) {
            status(t("fav.none", n + 1));
            return;
        }
        groupTag = FAV;
        index = n;
        lookYaw = 0;
        lookPitch = 0;
        lastSwitch = System.currentTimeMillis();
        Sfx.noise();
        remember();
        clearAndInit();
    }

    private Entry current() {
        List<Entry> l = list();
        if (l.isEmpty()) return null;
        index = Math.max(0, Math.min(index, l.size() - 1));
        return l.get(index);
    }

    private int indexOfIdx(int idx) {
        List<Entry> l = list();
        for (int i = 0; i < l.size(); i++) if (l.get(i).idx() == idx) return i;
        return -1;
    }

    private String nameOf(Entry e) {
        String a = e.meta().alias;
        return a == null || a.isBlank() ? t("camera.default", e.idx()).getString() : a;
    }

    private void remember() {
        Entry c = current();
        if (c != null) {
            Store.get().last.put(monitorKey, c.tag() + "#" + c.idx());
            Store.markDirty();
        }
    }

    private void status(Text s) {
        status = s;
        statusUntil = System.currentTimeMillis() + 4000;
    }

    private int nextIndex(String tag) {
        int max = 0;
        for (Entry e : entries(tag)) max = Math.max(max, e.idx());
        TagMeta tm = Store.get().tags.get(tag);
        if (tm != null) for (int i : tm.cams.keySet()) max = Math.max(max, i);
        for (Cameras.Live l : Cameras.live()) if (l.tag().equals(tag)) max = Math.max(max, l.index());
        if (client != null && client.player != null)
            for (int s = 0; s < 36; s++) {
                Heads.Parsed p = Heads.parse(client.player.getInventory().getStack(s));
                if (p.kind() == Heads.Kind.CAMERA && p.tag().equals(tag)) max = Math.max(max, p.index());
            }
        return max + 1;
    }

    private void copyName(String tag, int idx) {
        String name = Heads.cameraName(tag, idx);
        client.keyboard.setClipboard(name);
        status(t(name.length() > 50 ? "name.too_long" : "name.copied", name));
    }

    // ------------------------------------------------------------ жизненный цикл

    @Override
    protected void init() {
        rowEntries.clear();
        rowYs.clear();
        tabRects.clear();
        tabTags.clear();
        if (overlay != Overlay.NONE) {
            leaveView();
            buildOverlay();
            return;
        }
        if (mode == Mode.VIEW) enterView(); else leaveView();
        buildTop();
        buildTabs();
        if (mode == Mode.VIEW) buildView(); else buildSetup();
    }

    private void enterView() {
        if (enteredView) return;
        prevHud = client.options.hudHidden;
        prevPerspective = client.options.getPerspective();
        client.options.hudHidden = true;
        client.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        night = false;
        fxApplied = PostFx.apply(client, Theme.current().id());
        enteredView = true;
        remember();
    }

    private void applyFx() {
        if (enteredView && fxApplied) fxApplied = PostFx.apply(client, night ? "nightvision" : Theme.current().id());
    }

    private void leaveView() {
        Sfx.noSignal(false);
        CameraView.INSTANCE.deactivate();
        if (!enteredView) return;
        client.options.hudHidden = prevHud;
        client.options.setPerspective(prevPerspective);
        if (fxApplied) PostFx.clear(client);
        fxApplied = false;
        enteredView = false;
    }

    @Override
    public void removed() {
        Sfx.close();
        leaveView();
        Store.save();
    }

    @Override
    public void tick() {
        if (mode == Mode.VIEW && client.player != null && client.player.hurtTime > 0) close();
    }

    // ------------------------------------------------------------ виджеты

    private ThemedButton btn(int x, int y, int w, int h, Text label, Runnable r) {
        ThemedButton b = new ThemedButton(x, y, w, h, label, x0 -> r.run());
        addDrawableChild(b);
        return b;
    }

    private ThemedButton autoBtn(int[] cur, int maxX, int h, Text label, Runnable r) {
        int w = textRenderer.getWidth(label) + 14;
        if (cur[0] + w > maxX && cur[0] > panelX + 8) {
            cur[0] = panelX + 6;
            cur[1] += h + 4;
        }
        ThemedButton b = btn(cur[0], cur[1], w, h, label, r);
        cur[0] += w + 4;
        return b;
    }

    /** Одна компактная строка: [режим] [тема] вкладки групп … [закрыть]. */
    private void buildTop() {
        boolean view = mode == Mode.VIEW;
        btn(8, 3, 20, 18, Text.literal(view ? "⚙" : "▣"), () -> setMode(view ? Mode.SETUP : Mode.VIEW))
                .tip(t(view ? "tip.mode.setup" : "tip.mode.view"));
        btn(30, 3, 20, 18, Text.literal("◐"), () -> {
            ModConfig.get().theme = (UiUtil.shiftDown() ? Theme.prev(ModConfig.get().theme) : Theme.next(ModConfig.get().theme)).id();
            ModConfig.save();
            applyFx();
            clearAndInit();
        }).tip(t("theme", Theme.current().label()));
        btn(width - 28, 3, 20, 18, Text.literal("✕"), this::close).tip(t("tip.close"));
    }

    private void setMode(Mode m) {
        if (m == Mode.VIEW && tags().isEmpty()) {
            status(t("view.empty"));
            return;
        }
        if (m == Mode.VIEW && FAV.equals(groupTag) == false && groupTag.isEmpty() && !tags().contains("")) groupTag = tags().get(0);
        mode = m;
        movingIdx = -1;
        confirmDelete = null;
        autoCycle = false;
        clearAndInit();
    }

    private void buildTabs() {
        List<String> tg = tags();
        int x = 56;
        int n = tg.size();
        int fixed = (mode == Mode.VIEW ? 24 : 22) + 4;
        int tw = n == 0 ? 0 : Math.max(36, Math.min(110, (width - 56 - 34 - fixed - 4 * n) / n));
        if (mode == Mode.VIEW) {
            btn(x, 3, 20, 18, Text.literal("★"), () -> onTab(FAV)).toggled(() -> FAV.equals(groupTag)).tip(t("tip.fav"));
            x += 24;
        }
        for (String tag : tg) {
            String label = textRenderer.trimToWidth(tagLabel(tag), tw - 8);
            ThemedButton b = btn(x, 3, tw, 18, Text.literal(label), () -> onTab(tag));
            b.toggled(() -> groupTag.equals(tag));
            b.tip(Text.literal(tagLabel(tag)));
            tabRects.add(new int[]{x, tw});
            tabTags.add(tag);
            x += tw + 4;
        }
        if (mode == Mode.SETUP) {
            btn(x, 3, 20, 18, Text.literal("+"), () -> {
                overlay = Overlay.NEW_TAG;
                renameInitial = "";
                clearAndInit();
            }).tip(t("group.new"));
        }
    }

    private void onTab(String tag) {
        if (movingIdx >= 0 && mode == Mode.SETUP && !FAV.equals(tag)) {
            copyName(tag, nextIndex(tag));
            movingIdx = -1;
            clearAndInit();
            return;
        }
        groupTag = tag;
        index = 0;
        listScroll = 0;
        confirmDelete = null;
        remember();
        clearAndInit();
    }

    // ------------------------------------------------------------ ПРОСМОТР

    private void computeViewport() {
        int top = 25, bottom = height - 4;
        int availH = Math.max(40, bottom - top);
        int availW = width - 8;
        vh = (int) (availH * ModConfig.get().viewportScale);
        vw = Math.min(availW, (int) (vh * ((float) width / height)));
        vx = (width - vw) / 2;
        vy = top + (availH - vh) / 2;
    }

    private int stripX() { return vx + vw / 2 - 110; }

    private int stripY() { return vy + vh - 30; }

    private void buildView() {
        computeViewport();
        int x0 = stripX(), y0 = stripY() + 4;
        boolean multi = list().size() > 1;
        btn(x0, y0, 20, 20, Text.literal("◀"), () -> step(-1)).tip(t("tip.prev")).active = multi;
        btn(x0 + 132, y0, 20, 20, Text.literal("▶"), () -> step(1)).tip(t("tip.next")).active = multi;
        ThemedButton star = btn(x0 + 154, y0, 20, 20, Text.literal("★"), this::toggleFav);
        star.tip(t("tip.fav"));
        star.toggled(() -> {
            Entry c = current();
            return c != null && c.meta().favorite;
        });
        star.active = current() != null;
        btn(x0 + 176, y0, 20, 20, Text.literal("↻"), () -> {
            autoCycle = !autoCycle;
            Sfx.auto(autoCycle);
            lastSwitch = System.currentTimeMillis();
        }).toggled(() -> autoCycle).tip(t("tip.auto", ModConfig.get().autoCycleSeconds)).active = multi;
        btn(x0 + 198, y0, 20, 20, Text.literal("◉"), () -> shotPending = true).tip(t("tip.shot")).active = current() != null;
    }

    private void step(int d) {
        List<Entry> l = list();
        if (l.isEmpty()) return;
        index = (index + d + l.size()) % l.size();
        lookYaw = 0;
        lookPitch = 0;
        lastSwitch = System.currentTimeMillis();
        Sfx.noise();
        remember();
    }

    private float zoomOf(Entry e) {
        float z = e.meta().zoom;
        return z < 1f ? 1f : Math.min(z, 8f);
    }

    private void setZoom(float z) {
        Entry c = current();
        if (c == null) return;
        z = Math.max(1f, Math.min(8f, Math.round(z * 100f) / 100f));
        if (z != c.meta().zoom) {
            c.meta().zoom = z; // сохраняется в данных мира вместе с камерой
            Sfx.zoom();
            Store.markDirty();
        }
    }

    private void toggleFav() {
        Entry c = current();
        if (c == null) return;
        c.meta().favorite = !c.meta().favorite;
        Store.markDirty();
        if (FAV.equals(groupTag) && list().isEmpty()) {
            groupTag = tags().isEmpty() ? "" : tags().get(0);
            index = 0;
            clearAndInit();
        }
    }

    private void pollKeys() {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        long h = client.getWindow().getHandle();
        float sp = 70f * dt;
        int range = ModConfig.get().lookRange;
        if (GLFW.glfwGetKey(h, GLFW.GLFW_KEY_A) == GLFW.GLFW_PRESS) lookYaw -= sp;
        if (GLFW.glfwGetKey(h, GLFW.GLFW_KEY_D) == GLFW.GLFW_PRESS) lookYaw += sp;
        if (GLFW.glfwGetKey(h, GLFW.GLFW_KEY_W) == GLFW.GLFW_PRESS) lookPitch -= sp;
        if (GLFW.glfwGetKey(h, GLFW.GLFW_KEY_S) == GLFW.GLFW_PRESS) lookPitch += sp;
        lookYaw = Math.max(-range, Math.min(range, lookYaw));
        lookPitch = Math.max(-range / 2f, Math.min(range / 2f, lookPitch));
        Entry zc = current();
        if (zc != null) {
            float zf = (float) Math.pow(2.2, dt);
            if (GLFW.glfwGetKey(h, GLFW.GLFW_KEY_E) == GLFW.GLFW_PRESS) setZoom(zoomOf(zc) * zf);
            if (GLFW.glfwGetKey(h, GLFW.GLFW_KEY_Q) == GLFW.GLFW_PRESS) setZoom(zoomOf(zc) / zf);
        }
        for (int n = 0; n < 9; n++) {
            boolean down = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_1 + n) == GLFW.GLFW_PRESS;
            if (down && !prevNum[n]) jumpFav(n);
            prevNum[n] = down;
        }
        boolean l = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_RIGHT) == GLFW.GLFW_PRESS;
        if (l && !prevL) step(-1);
        if (r && !prevR) step(1);
        prevL = l;
        prevR = r;
        if (autoCycle && list().size() > 1
                && System.currentTimeMillis() - lastSwitch > ModConfig.get().autoCycleSeconds * 1000L) step(1);
    }

    private void updateCamera() {
        Entry cur = current();
        tooFar = false;
        weak = 0;
        if (cur == null || client.world == null) {
            signal = null;
            CameraView.INSTANCE.deactivate();
            return;
        }
        signal = Signal.resolve(Cameras.find(cur.tag(), cur.idx()), client.world, lastDelta);

        // Радиус действия: за пределом сигнал слабеет, в 1,5 раза дальше — пропадает.
        int range = ModConfig.get().signalRange;
        if (signal.ok() && range > 0 && client.player != null) {
            double r = signal.pos().distanceTo(client.player.getEyePos()) / range;
            if (r >= 1.5) {
                tooFar = true;
                signal = new Signal(false, Vec3d.ZERO, 0, 0, "");
            } else if (r > 1.0) {
                weak = (float) ((r - 1.0) / 0.5);
            }
        }

        if (!signal.ok()) {
            CameraView.INSTANCE.deactivate();
            return;
        }

        // Ночное видение: включается, когда в точке камеры темно (с гистерезисом, чтобы не мигать).
        if (ModConfig.get().nightVision && fxApplied) {
            long now = System.currentTimeMillis();
            if (now - lightCheck > 250) {
                lightCheck = now;
                int lvl = client.world.getLightLevel(BlockPos.ofFloored(signal.pos()), client.world.getAmbientDarkness());
                boolean want = night ? lvl <= 6 : lvl <= 3;
                if (want != night) {
                    night = want;
                    applyFx();
                }
            }
        } else if (night) {
            night = false;
            applyFx();
        }
        float pitch = Math.max(-89f, Math.min(89f, signal.pitch() + lookPitch));
        CameraView.INSTANCE.set(signal.pos(), signal.yaw() + lookYaw, pitch, zoomOf(cur));
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        if (overlay == Overlay.NONE) {
            if (mode == Mode.SETUP) {
                listScroll = Math.max(0, listScroll + (v > 0 ? -1 : 1));
                clearAndInit();
                return true;
            }
            Entry c = current();
            if (c != null) setZoom(zoomOf(c) * (v > 0 ? 1.15f : 1f / 1.15f));
            return true;
        }
        return super.mouseScrolled(mx, my, h, v);
    }

    private void ctext(DrawContext g, String s, int cx, int y, int color, boolean shadow) {
        g.drawText(textRenderer, s, cx - textRenderer.getWidth(s) / 2, y, color, shadow);
    }

    private FeedEffects.Info info(Entry cur) {
        var p = signal.pos();
        return new FeedEffects.Info(nameOf(cur), p.x, p.y, p.z, signal.yaw() + lookYaw, signal.pitch() + lookPitch, signal.src());
    }

    private void drawView(DrawContext g, Theme t, boolean shot) {
        Entry cur = current();
        boolean ok = cur != null && signal != null && signal.ok();
        if (!shot) {
            g.fill(0, 0, width, vy, t.bg());
            g.fill(0, vy + vh, width, height, t.bg());
            g.fill(0, vy, vx, vy + vh, t.bg());
            g.fill(vx + vw, vy, width, vy + vh, t.bg());
        }
        if (!ok) {
            if (shot) return;
            String sub = cur == null ? t("view.empty").getString() : t(tooFar ? "signal.far" : "signal.offline").getString();
            FeedEffects.noSignal(g, textRenderer, t, vx, vy, vw, vh, t("signal.none").getString(), sub);
        } else {
            FeedEffects.draw(g, textRenderer, t, vx, vy, vw, vh, info(cur), fxApplied);
            if (!shot && weak > 0) FeedEffects.interference(g, textRenderer, t, vx, vy, vw, vh, weak, System.currentTimeMillis());
            if (!shot && night) {
                String nv = "◐ NIGHT VISION";
                g.drawText(textRenderer, nv, vx + vw - 8 - textRenderer.getWidth(nv), vy + 36, 0xFF7CFF8C, true);
            }
            if (!shot && ModConfig.get().showCoords && !t.id().equals("tactical") && !t.id().equals("cyber")) {
                var p = signal.pos();
                String c = (int) p.x + " " + (int) p.y + " " + (int) p.z;
                g.drawText(textRenderer, c, vx + vw - 8 - textRenderer.getWidth(c), vy + 24, 0xFFFFFFFF, true);
            }
            if (Cameras.hasMotion(cur.tag(), cur.idx()) && (System.currentTimeMillis() / 300) % 2 == 0) {
                String m = "⚠ " + t("motion.label").getString();
                g.fill(vx + vw / 2 - textRenderer.getWidth(m) / 2 - 6, vy + 8, vx + vw / 2 + textRenderer.getWidth(m) / 2 + 6, vy + 22, 0xB0000000);
                ctext(g, m, vx + vw / 2, vy + 11, t.bad(), false);
            }
        }
        if (shot) return;
        FeedEffects.frame(g, t, vx, vy, vw, vh);

        // Компактная панель управления поверх нижнего края изображения.
        int x0 = stripX(), y0 = stripY();
        UiUtil.rounded(g, x0 - 4, y0, 226, 28, t.panel(), t.border());
        if (cur != null) {
            String zoom = zoomOf(cur) > 1.01f ? "  ×" + String.format(Locale.ROOT, "%.1f", zoomOf(cur)) : "";
            int fn = cur.meta().favorite ? favNo(cur) : 0;
            String nm = textRenderer.trimToWidth((cur.meta().favorite ? "★" + (fn >= 1 && fn <= 9 ? fn : "") + " " : "") + nameOf(cur), 106);
            ctext(g, nm, x0 + 77, y0 + 5, t.text(), false);
            String sub = textRenderer.trimToWidth((index + 1) + "/" + list().size() + " · " + tagLabel(cur.tag()) + zoom, 106);
            ctext(g, sub, x0 + 77, y0 + 16, t.dim(), false);
        } else {
            ctext(g, t("view.empty").getString(), x0 + 77, y0 + 10, t.dim(), false);
        }
        g.drawText(textRenderer, textRenderer.trimToWidth(t("view.hint").getString(), Math.max(0, vw / 2 - 126)),
                vx + 8, vy + vh - 14, 0xB0FFFFFF, true);
    }

    private void takeShot(Entry cur) {
        Sfx.shutter();
        String file = "cam_" + (cur.tag().isEmpty() ? "" : cur.tag().replaceAll("[^\\p{L}\\p{N}_-]", "_") + "_") + cur.idx()
                + "_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".png";
        ScreenshotRecorder.saveScreenshot(client.runDirectory, file, client.getFramebuffer(), 1,
                msg -> client.execute(() -> client.inGameHud.getChatHud().addMessage(msg)));
    }

    // ------------------------------------------------------------ НАСТРОЙКА

    private int cellX(int slot) { return gridX + (slot < 9 ? slot : (slot - 9) % 9) * CELL; }

    private int cellY(int slot) {
        int row = slot < 9 ? 3 : (slot - 9) / 9;
        return gridY + row * CELL + (row == 3 ? 6 : 0);
    }

    private void buildSetup() {
        panelX = 8;
        panelY = 26;
        panelW = width - 16;
        panelH = height - 30;
        leftW = Math.min(Math.max(250, (int) (panelW * 0.58)), panelW - 196);
        rightX = panelX + leftW + 8;
        int rightW = panelW - leftW - 8;
        if (FAV.equals(groupTag)) groupTag = tags().isEmpty() ? "" : tags().get(0);

        int[] c = {panelX + 5, panelY + 5};
        int maxX = panelX + leftW - 4;
        autoBtn(c, maxX, 16, t("group.new"), () -> { overlay = Overlay.NEW_TAG; renameInitial = ""; clearAndInit(); });
        autoBtn(c, maxX, 16, t("name.camera"), () -> copyName(groupTag, nextIndex(groupTag))).tip(t("name.camera.tip"));
        autoBtn(c, maxX, 16, t("name.monitor"), () -> {
            client.keyboard.setClipboard(Heads.monitorName(monitorTags.isEmpty() ? List.of(groupTag).stream().filter(s -> !s.isEmpty()).toList() : monitorTags));
            status(t("name.copied", client.keyboard.getClipboard()));
        }).tip(t("name.monitor.tip"));
        boolean confirm = groupTag.equals(confirmDelete);
        ThemedButton del = autoBtn(c, maxX, 16, t(confirm ? "group.reset.confirm" : "group.reset"), this::resetGroup);
        if (confirm) del.danger();

        int listTop = c[1] + 22;
        int rowH = 20;
        List<Entry> cams = entries(groupTag);
        int visible = Math.max(1, (panelY + panelH - 18 - listTop) / rowH);
        listScroll = Math.max(0, Math.min(listScroll, Math.max(0, cams.size() - visible)));
        int bx = panelX + leftW - 6 - 7 * 20 + 2;
        for (int r = 0; r < visible && listScroll + r < cams.size(); r++) {
            int i = listScroll + r;
            Entry e = cams.get(i);
            int ry = listTop + r * rowH;
            rowEntries.add(e);
            rowYs.add(ry);
            btn(bx, ry + 1, 18, 18, Text.literal("✎"), () -> {
                overlay = Overlay.RENAME_CAM;
                renameIdx = e.idx();
                renameInitial = e.meta().alias == null ? "" : e.meta().alias;
                clearAndInit();
            }).tip(t("tip.rename"));
            btn(bx + 20, ry + 1, 18, 18, Text.literal("▲"), () -> swap(groupTag, cams, i, i - 1)).tip(t("tip.up")).active = i > 0;
            btn(bx + 40, ry + 1, 18, 18, Text.literal("▼"), () -> swap(groupTag, cams, i, i + 1)).tip(t("tip.down")).active = i < cams.size() - 1;
            btn(bx + 60, ry + 1, 18, 18, Text.literal("★"), () -> { e.meta().favorite = !e.meta().favorite; Store.markDirty(); clearAndInit(); })
                    .toggled(() -> e.meta().favorite).tip(t("tip.fav"));
            btn(bx + 80, ry + 1, 18, 18, Text.literal("⇄"), () -> { movingIdx = movingIdx == e.idx() ? -1 : e.idx(); clearAndInit(); })
                    .toggled(() -> movingIdx == e.idx()).tip(t("tip.move")).active = tags().size() > 1;
            btn(bx + 100, ry + 1, 18, 18, Text.literal("⎘"), () -> copyName(e.tag(), e.idx())).tip(t("tip.copyname"));
            btn(bx + 120, ry + 1, 18, 18, Text.literal("✕"), () -> { e.meta().hidden = true; Store.markDirty(); clearAndInit(); })
                    .danger().tip(t("tip.hide"));
        }

        // превью инвентаря: только головы Camera
        gridX = rightX + Math.max(0, (rightW - 9 * CELL) / 2);
        gridY = panelY + 30;
        nameCounter = nextIndex(groupTag);
        var player = client.player;
        for (int s = 0; s < 36; s++) {
            final int slot = s;
            ItemStack st = player == null ? ItemStack.EMPTY : player.getInventory().getStack(slot);
            Heads.Parsed p = Heads.parse(st);
            camSlot[slot] = p.kind() == Heads.Kind.CAMERA;
            if (!camSlot[slot]) continue;
            Supplier<ItemStack> sup = () -> client.player == null ? ItemStack.EMPTY : client.player.getInventory().getStack(slot);
            boolean match = p.tag().equals(groupTag);
            SlotButton sb = new SlotButton(cellX(slot), cellY(slot), sup, () -> match ? 1 : 0, b -> {
                copyName(groupTag, nameCounter++);
            });
            sb.setTooltip(Tooltip.of(Text.literal(st.getName().getString() + " → " + t("slot.tip").getString())));
            addDrawableChild(sb);
        }
    }

    private void swap(String tag, List<Entry> l, int a, int b) {
        if (a < 0 || b < 0 || a >= l.size() || b >= l.size()) return;
        TagMeta tm = Store.get().tag(tag);
        tm.order.clear();
        for (Entry e : l) tm.order.add(e.idx());
        Collections.swap(tm.order, a, b);
        Store.markDirty();
        clearAndInit();
    }

    private void resetGroup() {
        if (!groupTag.equals(confirmDelete)) {
            confirmDelete = groupTag;
            clearAndInit();
            return;
        }
        Store.get().tags.remove(groupTag);
        Store.get().drafts.remove(groupTag);
        confirmDelete = null;
        List<String> tg = tags();
        groupTag = tg.isEmpty() ? "" : tg.get(0);
        index = 0;
        Store.markDirty();
        clearAndInit();
    }

    private void drawSetup(DrawContext g, Theme t) {
        g.fill(0, 0, width, height, t.bg());
        UiUtil.rounded(g, panelX, panelY, leftW, panelH, t.panel(), t.border());
        UiUtil.rounded(g, rightX, panelY, panelW - leftW - 8, panelH, t.panel(), t.border());

        int nameMax = leftW - 7 * 20 - 40;
        for (int i = 0; i < rowEntries.size(); i++) {
            Entry e = rowEntries.get(i);
            int ry = rowYs.get(i);
            boolean mv = movingIdx == e.idx();
            UiUtil.rounded(g, panelX + 4, ry, leftW - 8, 20, mv ? UiUtil.mix(t.panelAlt(), t.accent(), 0.3f) : t.panelAlt(), mv ? t.accent() : t.border());
            boolean live = Cameras.find(e.tag(), e.idx()) != null;
            int dot = Cameras.hasMotion(e.tag(), e.idx()) ? 0xFFE0A030 : live ? t.good() : t.bad();
            g.fill(panelX + 10, ry + 7, panelX + 16, ry + 13, dot);
            g.drawText(textRenderer, textRenderer.trimToWidth(nameOf(e), nameMax), panelX + 22, ry + 6, t.text(), false);
        }
        if (rowEntries.isEmpty())
            g.drawText(textRenderer, t("setup.empty_list").getString(), panelX + 12, panelY + panelH / 2, t.dim(), false);
        String hint = movingIdx >= 0 ? t("setup.moving").getString() : t("setup.legend").getString();
        g.drawText(textRenderer, hint, panelX + 8, panelY + panelH - 14, movingIdx >= 0 ? t.accent() : t.dim(), false);

        int total = 0;
        for (int s = 0; s < 36; s++) {
            ItemStack st = client.player == null ? ItemStack.EMPTY : client.player.getInventory().getStack(s);
            if (camSlot[s]) total += st.getCount();
        }
        g.drawText(textRenderer, t("setup.inv.title", total).getString(), gridX, panelY + 6, t.text(), false);
        g.drawText(textRenderer, t("setup.inv.hint").getString(), gridX, panelY + 17, t.dim(), false);
        for (int s = 0; s < 36; s++) {
            if (camSlot[s]) continue;
            UiUtil.rounded(g, cellX(s), cellY(s), CELL, CELL, UiUtil.mix(t.panel(), t.panelAlt(), 0.5f), UiUtil.mix(t.panel(), t.border(), 0.6f));
        }
        int below = gridY + 4 * CELL + 12;
        g.drawText(textRenderer, t("setup.group", tagLabel(groupTag)).getString(), gridX, below, t.accent(), false);
        g.drawText(textRenderer, t("setup.next", Heads.cameraName(groupTag, nameCounter)).getString(), gridX, below + 12, t.dim(), false);
        if (total == 0) g.drawText(textRenderer, t("setup.inv.none").getString(), gridX, below + 26, t.dim(), false);
    }

    // ------------------------------------------------------------ окна ввода

    private void closeOverlay() {
        overlay = Overlay.NONE;
        field = null;
        clearAndInit();
    }

    private void applyOverlay() {
        String v = field == null ? "" : field.getText().trim();
        if (overlay == Overlay.RENAME_CAM) {
            for (Entry e : entries(groupTag)) if (e.idx() == renameIdx) e.meta().alias = v;
            Store.markDirty();
        } else if (overlay == Overlay.NEW_TAG) {
            String tag = v.toLowerCase(Locale.ROOT).replace(",", "");
            if (!tag.isEmpty()) {
                if (!tags().contains(tag)) Store.get().drafts.add(tag);
                groupTag = tag;
                listScroll = 0;
                Store.markDirty();
            }
        }
        closeOverlay();
    }

    private void buildOverlay() {
        int cx = width / 2, cy = height / 2;
        dw = 250; dh = 90; dx = cx - dw / 2; dy = cy - dh / 2;
        field = new TextFieldWidget(textRenderer, dx + 12, dy + 32, dw - 24, 18, Text.empty());
        field.setMaxLength(overlay == Overlay.NEW_TAG ? 24 : 32);
        field.setText(renameInitial);
        addDrawableChild(field);
        setInitialFocus(field);
        int bw = (dw - 28) / 2;
        btn(dx + 12, dy + 60, bw, 20, t("ok"), this::applyOverlay);
        btn(dx + 16 + bw, dy + 60, bw, 20, t("cancel"), this::closeOverlay);
    }

    // ------------------------------------------------------------ отрисовка

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        Theme t = Theme.current();
        lastDelta = delta;
        boolean shot = false;
        boolean wantStatic = false;
        if (overlay != Overlay.NONE) {
            g.fill(0, 0, width, height, t.bg());
            UiUtil.rounded(g, dx, dy, dw, dh, t.panel(), t.accent());
            g.drawText(textRenderer, t(overlay == Overlay.NEW_TAG ? "group.new.title" : "rename.cam").getString(), dx + 12, dy + 14, t.text(), false);
        } else if (mode == Mode.VIEW) {
            pollKeys();
            updateCamera();
            if (shotPending && current() != null && signal != null && signal.ok()) {
                shotPending = false;
                shot = true;
            } else {
                shotPending = false;
            }
            wantStatic = !shot && current() != null && (signal == null || !signal.ok() || weak > 0.5f);
            drawView(g, t, shot);
            if (shot) {
                takeShot(current());
                return; // этот кадр — только изображение, без кнопок
            }
        } else {
            drawSetup(g, t);
        }
        Sfx.noSignal(wantStatic);
        super.render(g, mx, my, delta);
        for (int i = 0; i < tabRects.size(); i++)
            if (Cameras.tagHasMotion(tabTags.get(i)) && (System.currentTimeMillis() / 300) % 2 == 0)
                g.fill(tabRects.get(i)[0] + tabRects.get(i)[1] - 9, 6, tabRects.get(i)[0] + tabRects.get(i)[1] - 4, 11, 0xFFE0A030);
        if (System.currentTimeMillis() < statusUntil) {
            String s = status.getString();
            int w = textRenderer.getWidth(s) + 16;
            int x = (width - w) / 2, y = height - 24;
            UiUtil.rounded(g, x, y, w, 16, t.panelAlt(), t.accent());
            g.drawText(textRenderer, s, x + 8, y + 4, t.text(), false);
        }
    }

    // ------------------------------------------------------------ слот

    private static final class SlotButton extends ButtonWidget {
        private final Supplier<ItemStack> stack;
        private final IntSupplier match;

        SlotButton(int x, int y, Supplier<ItemStack> stack, IntSupplier match, PressAction action) {
            super(x, y, CELL, CELL, net.minecraft.text.Text.empty(), action, DEFAULT_NARRATION_SUPPLIER);
            this.stack = stack;
            this.match = match;
        }

        @Override
        protected void drawIcon(DrawContext g, int mx, int my, float delta) {
            Theme t = Theme.current();
            boolean m = match.getAsInt() > 0;
            UiUtil.rounded(g, getX(), getY(), getWidth(), getHeight(),
                    m ? UiUtil.mix(t.panelAlt(), t.accent(), 0.4f) : t.panelAlt(),
                    m || isHovered() ? t.accent() : t.border());
            ItemStack s = stack.get();
            TextRenderer tr = MinecraftClient.getInstance().textRenderer;
            g.drawItem(s, getX() + 2, getY() + 2);
            g.drawStackOverlay(tr, s, getX() + 2, getY() + 2);
        }
    }
}
