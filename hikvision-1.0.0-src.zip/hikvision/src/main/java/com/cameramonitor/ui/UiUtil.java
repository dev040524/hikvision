package com.cameramonitor.ui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class UiUtil {
    private UiUtil() {}

    /** Панель с рамкой в 1 пиксель (углы скруглены или квадратные — зависит от темы). Фон может быть полупрозрачным. */
    public static void rounded(DrawContext c, int x, int y, int w, int h, int bg, int border) {
        if (Theme.current().square()) {
            c.fill(x, y, x + w, y + 1, border);
            c.fill(x, y + h - 1, x + w, y + h, border);
            c.fill(x, y + 1, x + 1, y + h - 1, border);
            c.fill(x + w - 1, y + 1, x + w, y + h - 1, border);
            c.fill(x + 1, y + 1, x + w - 1, y + h - 1, bg);
            return;
        }
        c.fill(x + 2, y, x + w - 2, y + 1, border);
        c.fill(x + 2, y + h - 1, x + w - 2, y + h, border);
        c.fill(x, y + 2, x + 1, y + h - 2, border);
        c.fill(x + w - 1, y + 2, x + w, y + h - 2, border);
        c.fill(x + 1, y + 1, x + 2, y + 2, border);
        c.fill(x + w - 2, y + 1, x + w - 1, y + 2, border);
        c.fill(x + 1, y + h - 2, x + 2, y + h - 1, border);
        c.fill(x + w - 2, y + h - 2, x + w - 1, y + h - 1, border);
        c.fill(x + 2, y + 1, x + w - 2, y + h - 1, bg);
        c.fill(x + 1, y + 2, x + w - 1, y + h - 2, bg);
    }

    /** Линейное смешивание ARGB-цветов (включая альфу). */
    public static int mix(int a, int b, float f) {
        int r = 0;
        for (int s = 0; s <= 24; s += 8) {
            int ca = (a >>> s) & 0xFF, cb = (b >>> s) & 0xFF;
            r |= ((int) (ca + (cb - ca) * f) & 0xFF) << s;
        }
        return r;
    }

    public static void outline(DrawContext g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + 1, c);
        g.fill(x, y + h - 1, x + w, y + h, c);
        g.fill(x, y + 1, x + 1, y + h - 1, c);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, c);
    }

    public static boolean shiftDown() {
        var window = MinecraftClient.getInstance().getWindow();
        return InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_LEFT_SHIFT)
                || InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_RIGHT_SHIFT);
    }
}
