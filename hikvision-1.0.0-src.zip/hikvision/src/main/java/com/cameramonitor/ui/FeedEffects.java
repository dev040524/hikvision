package com.cameramonitor.ui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

/**
 * Оформление изображения камеры: наложения поверх уже отрисованного мира.
 * Настоящих шейдеров нет (клиентский мод без ресурсов шейдеров), поэтому «ч/б» и «монохром»
 * имитируются полупрозрачной тонировкой, шумом и полосами.
 */
public final class FeedEffects {
    public record Info(String name, double x, double y, double z, float yaw, float pitch, String src) {}

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private FeedEffects() {}

    public static void draw(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, boolean shaderOn) {
        long now = System.currentTimeMillis();
        // Если включён шейдер, серость и тонировка уже применены к миру — накладываем только шум и графику.
        if (!shaderOn && (t.tint() >>> 24) > 0) g.fill(x, y, x + w, y + h, t.tint());
        if (t.scan() > 0) for (int yy = y; yy < y + h; yy += 3) g.fill(x, yy, x + w, yy + 1, t.scan() << 24);
        noise(g, t, x, y, w, h, now);
        glitch(g, t, x, y, w, h, now);
        switch (t.id()) {
            case "classic" -> classic(g, tr, t, x, y, w, h, i, now);
            case "night" -> night(g, tr, t, x, y, w, h, i, now);
            case "tape" -> tape(g, tr, t, x, y, w, h, i, now);
            case "cyber" -> cyber(g, tr, t, x, y, w, h, i, now);
            case "tactical" -> tactical(g, tr, t, x, y, w, h, i, now);
            case "vhs" -> vhs(g, tr, t, x, y, w, h, i, now);
            case "ghost" -> ghost(g, tr, t, x, y, w, h, i, now);
            case "blueprint" -> blueprint(g, tr, t, x, y, w, h, i, now);
            case "neon" -> neon(g, tr, t, x, y, w, h, i, now);
            case "thermal" -> thermal(g, tr, t, x, y, w, h, i, now);
            case "hazard" -> hazard(g, tr, t, x, y, w, h, i, now);
            case "arctic" -> arctic(g, tr, t, x, y, w, h, i, now);
            case "pixel" -> pixel(g, tr, t, x, y, w, h, i, now);
            default -> { }
        }
    }

    /** Рамка вокруг области изображения: толщина/свечение зависят от темы. */
    public static void frame(DrawContext g, Theme t, int x, int y, int w, int h) {
        if (t.glow() != 0) {
            int ga = t.glow() >>> 24;
            for (int k = 1; k <= 4; k++)
                UiUtil.outline(g, x - 1 - k, y - 1 - k, w + 2 + 2 * k, h + 2 + 2 * k, ((ga / (k + 1)) << 24) | (t.glow() & 0xFFFFFF));
        }
        UiUtil.outline(g, x - 1, y - 1, w + 2, h + 2, t.accent());
        if (t.square()) UiUtil.outline(g, x - 2, y - 2, w + 4, h + 4, t.border());
    }

    /** Заставка «нет сигнала»: плотный шум, бегущие полосы и мигающая надпись. */
    public static void noSignal(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, String title, String sub) {
        long now = System.currentTimeMillis();
        g.fill(x, y, x + w, y + h, 0xFF07090C);
        Random r = new Random(now / 60);
        int n = w * h / 220;
        for (int k = 0; k < n; k++) {
            int px = x + r.nextInt(Math.max(1, w - 4)), py = y + r.nextInt(Math.max(1, h - 2));
            int gr = 40 + r.nextInt(150);
            g.fill(px, py, px + 1 + r.nextInt(4), py + 1 + r.nextInt(2), 0xFF000000 | gr << 16 | gr << 8 | gr);
        }
        for (int k = 0; k < 2; k++) {
            int by = y + (int) ((now / (5 + 3 * k)) % (h + 60)) - 30;
            int y1 = Math.max(y, by), y2 = Math.min(y + h, by + 22);
            if (y2 > y1) g.fillGradient(x, y1, x + w, y2, 0x00FFFFFF, 0x38FFFFFF);
        }
        for (int yy = y; yy < y + h; yy += 3) g.fill(x, yy, x + w, yy + 1, 0x30000000);
        int cx = x + w / 2, cy = y + h / 2;
        int bw = Math.max(tr.getWidth(title), tr.getWidth(sub)) + 24;
        g.fill(cx - bw / 2, cy - 22, cx + bw / 2, cy + 20, 0xB0000000);
        UiUtil.outline(g, cx - bw / 2, cy - 22, bw, 42, t.dim());
        int tc = (now / 500) % 2 == 0 ? t.bad() : (t.bad() & 0xFFFFFF) | 0x66000000;
        g.drawText(tr, title, cx - tr.getWidth(title) / 2, cy - 12, tc, true);
        g.drawText(tr, sub, cx - tr.getWidth(sub) / 2, cy + 3, 0xFFB0B8C4, false);
    }


    /** Слабый сигнал: помехи растут вместе с amount (0..1), рвётся строчная развёртка, мигает индикатор. */
    public static void interference(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, float amount, long now) {
        Random r = new Random(now / 55);
        int n = (int) (amount * w * h / 90f);
        for (int k = 0; k < n; k++) {
            int px = x + r.nextInt(Math.max(1, w - 4)), py = y + r.nextInt(Math.max(1, h - 1));
            int a = 0x60 + r.nextInt(0x70);
            g.fill(px, py, px + 1 + r.nextInt(4), py + 1, (a << 24) | (r.nextBoolean() ? 0xFFFFFF : 0));
        }
        int bars = 1 + (int) (amount * 6);
        for (int k = 0; k < bars; k++) {
            int by = y + r.nextInt(Math.max(1, h - 10));
            g.fill(x, by, x + w, by + 2 + r.nextInt(7), 0x50FFFFFF);
            if (amount > 0.5f) g.fill(x, y + r.nextInt(Math.max(1, h - 4)), x + w, y + r.nextInt(Math.max(1, h - 4)) + 1 + r.nextInt(3), 0xFF000000);
        }
        if (r.nextFloat() < amount * 0.25f) g.fill(x, y, x + w, y + h, 0x30000000);
        int lit = 1 + (int) ((1f - amount) * 3f);
        int bx = x + w / 2 - 22, by2 = y + 34;
        for (int k = 0; k < 4; k++) {
            int bh = 4 + k * 3;
            g.fill(bx + k * 6, by2 + 13 - bh, bx + k * 6 + 4, by2 + 13, k < lit ? t.good() : 0x60FFFFFF);
        }
        if ((now / 450) % 2 == 0) g.drawText(tr, "WEAK SIGNAL", bx + 28, by2 + 3, t.bad(), true);
    }

    // ---------------------------------------------------------------- общие эффекты

    private static void noise(DrawContext g, Theme t, int x, int y, int w, int h, long now) {
        int n = (int) (t.noise() * w * h / 500f);
        Random r = new Random(now / 70);
        for (int k = 0; k < n; k++) {
            int px = x + r.nextInt(Math.max(1, w - 3)), py = y + r.nextInt(Math.max(1, h - 1));
            int a = 0x30 + r.nextInt(0x70);
            int v = r.nextBoolean() ? 0xFFFFFF : 0;
            g.fill(px, py, px + 1 + r.nextInt(3), py + 1, (a << 24) | v);
        }
    }

    private static void glitch(DrawContext g, Theme t, int x, int y, int w, int h, long now) {
        if (t.glitch() <= 0) return;
        Random r = new Random(now / 50);
        if (now % 5000 < (long) (500 * t.glitch())) {
            g.fill(x, y, x + w, y + h, 0x14FFFFFF);
            int bars = 2 + (int) (6 * t.glitch());
            for (int k = 0; k < bars; k++) {
                int by = y + r.nextInt(Math.max(1, h - 12)), bh = 2 + r.nextInt(10);
                g.fill(x, by, x + w, by + bh, 0x40FFFFFF);
                g.fill(x + r.nextInt(w / 4 + 1), by, x + w, by + 1, 0x90000000);
            }
        }
        if (t.glitch() >= 0.25f) { // «трекинг» — бегущая светлая полоса
            int by = y + (int) ((now / 8) % (h + 40)) - 20;
            int y1 = Math.max(y, by), y2 = Math.min(y + h, by + 14);
            if (y2 > y1) g.fillGradient(x, y1, x + w, y2, 0x00FFFFFF, 0x30FFFFFF);
        }
    }

    private static int flick(Theme t, long now, int color) {
        if (t.flicker() > 0 && new Random(now / 90).nextFloat() < t.flicker() * 0.25f)
            return (color & 0xFFFFFF) | 0x66000000;
        return color;
    }

    private static void text(DrawContext g, TextRenderer tr, String s, int x, int y, int color) {
        g.drawText(tr, s, x, y, color, true);
    }

    private static void textR(DrawContext g, TextRenderer tr, String s, int right, int y, int color) {
        g.drawText(tr, s, right - tr.getWidth(s), y, color, true);
    }

    private static void recDot(DrawContext g, int x, int y, int color, long now, long period) {
        if ((now / period) % 2 == 0) g.fill(x, y, x + 6, y + 6, color);
    }

    private static void brackets(DrawContext g, int x, int y, int w, int h, int len, int c) {
        g.fill(x, y, x + len, y + 2, c); g.fill(x, y, x + 2, y + len, c);
        g.fill(x + w - len, y, x + w, y + 2, c); g.fill(x + w - 2, y, x + w, y + len, c);
        g.fill(x, y + h - 2, x + len, y + h, c); g.fill(x, y + h - len, x + 2, y + h, c);
        g.fill(x + w - len, y + h - 2, x + w, y + h, c); g.fill(x + w - 2, y + h - len, x + w, y + h, c);
    }

    private static String stamp() { return LocalDateTime.now().format(TS); }

    private static int heading(float yaw) { return (((int) (yaw + 180f)) % 360 + 360) % 360; }

    // ---------------------------------------------------------------- темы

    private static void classic(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        brackets(g, x + 6, y + 6, w - 12, h - 12, 16, t.accent());
        recDot(g, x + 16, y + 17, 0xFFFF3030, now, 600);
        text(g, tr, "CAM  " + i.name(), x + 28, y + 16, flick(t, now, t.text()));
        text(g, tr, stamp(), x + 16, y + h - 24, flick(t, now + 90, t.accent()));
        textR(g, tr, "SRC:" + i.src(), x + w - 16, y + 16, t.dim());
    }

    private static void night(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        int pulse = (int) ((Math.sin(now / 700.0) + 1) * 0.5 * 0x38);
        int c = ((0x18 + pulse) << 24) | 0xC00000;
        g.fillGradient(x, y, x + w, y + 34, c, 0x00C00000);
        g.fillGradient(x, y + h - 34, x + w, y + h, 0x00C00000, c);
        recDot(g, x + 14, y + 14, t.bad(), now, 900);
        text(g, tr, i.name(), x + 26, y + 13, flick(t, now, t.text()));
        text(g, tr, stamp(), x + 14, y + h - 22, t.dim());
        textR(g, tr, "NIGHT", x + w - 14, y + 13, t.accent());
    }

    private static void tape(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        Random r = new Random(now / 90);
        if (r.nextInt(5) == 0) { // царапина плёнки
            int sx = x + r.nextInt(w), sh = 6 + r.nextInt(30);
            g.fill(sx, y + r.nextInt(Math.max(1, h - sh)), sx + 1, y + h, 0x30FFFFFF);
        }
        long sec = (now / 1000) % 3600;
        text(g, tr, "▶ PLAY", x + 14, y + 14, flick(t, now, t.accent()));
        textR(g, tr, "SP", x + w - 14, y + 14, t.accent());
        text(g, tr, i.name(), x + 14, y + 26, t.text());
        text(g, tr, String.format("00:%02d:%02d   %s", sec / 60, sec % 60, stamp()), x + 14, y + h - 22, t.text());
    }

    private static void cyber(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        int grid = 0x14000000 | (t.accent() & 0xFFFFFF);
        for (int gx = x + 32; gx < x + w; gx += 32) g.fill(gx, y, gx + 1, y + h, grid);
        for (int gy = y + 32; gy < y + h; gy += 32) g.fill(x, gy, x + w, gy + 1, grid);
        brackets(g, x + 8, y + 8, w - 16, h - 16, 12, t.accent());
        int sweep = x + (int) ((now / 12) % Math.max(1, w));
        g.fill(sweep, y, sweep + 1, y + h, 0x2020E3D0);
        text(g, tr, "◉ " + i.name(), x + 18, y + 18, t.accent());
        text(g, tr, String.format("%.0f %.0f %.0f", i.x(), i.y(), i.z()), x + 18, y + h - 24, t.text());
        textR(g, tr, i.src(), x + w - 18, y + 18, t.dim());
    }

    private static void tactical(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        int a = t.accent(), cx = x + w / 2, cy = y + h / 2;
        g.fill(cx - 22, cy, cx - 6, cy + 1, a); g.fill(cx + 6, cy, cx + 22, cy + 1, a);
        g.fill(cx, cy - 22, cx + 1, cy - 6, a); g.fill(cx, cy + 6, cx + 1, cy + 22, a);
        g.fill(cx, cy, cx + 1, cy + 1, 0xFFFF4030);
        brackets(g, cx - 36, cy - 36, 72, 72, 8, a);
        int tick = 0x90000000 | (a & 0xFFFFFF);
        for (int k = 0, tx = x + 16; tx < x + w - 8; tx += 16, k++) {
            int len = k % 4 == 0 ? 8 : 4;
            g.fill(tx, y, tx + 1, y + len, tick);
            g.fill(tx, y + h - len, tx + 1, y + h, tick);
        }
        text(g, tr, "CAM // " + i.name().toUpperCase(), x + 14, y + 14, t.text());
        textR(g, tr, "SRC " + i.src(), x + w - 14, y + 14, a);
        text(g, tr, String.format("HDG %03d  PIT %+d", heading(i.yaw()), (int) i.pitch()), x + 14, y + h - 24, a);
        textR(g, tr, String.format("X%.0f Y%.0f Z%.0f", i.x(), i.y(), i.z()), x + w - 14, y + h - 24, t.text());
    }

    private static void vhs(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        Random r = new Random(now / 110);
        char[] ts = stamp().toCharArray();
        if (r.nextFloat() < 0.5f)
            for (int k = 0; k < 2; k++) {
                int p = r.nextInt(ts.length);
                if (Character.isDigit(ts[p])) ts[p] = (char) ('0' + r.nextInt(10));
            }
        int jx = r.nextInt(100) < 15 ? r.nextInt(5) - 2 : 0;
        text(g, tr, "PLAY ▶", x + 16, y + 16, flick(t, now, 0xFFFFFFFF));
        textR(g, tr, "SP  " + i.name(), x + w - 16, y + 16, t.text());
        text(g, tr, new String(ts), x + 16 + jx, y + h - 26, flick(t, now + 40, 0xFFFFFFFF));
        recDot(g, x + w - 28, y + h - 26, t.bad(), now, 500);
    }

    private static void ghost(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        g.fillGradient(x, y, x + w, y + h / 3, 0x80000000, 0x00000000);
        g.fillGradient(x, y + h * 2 / 3, x + w, y + h, 0x00000000, 0x90000000);
        text(g, tr, i.name(), x + 16, y + h - 24, 0xB0CFEFD8);
        if ((now / 1400) % 2 == 0) g.fill(x + 16, y + 16, x + 20, y + 20, 0xA04DFF88);
    }

    // ---------------------------------------------------------------- новые темы

    private static void blueprint(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        for (int gx = x + 16; gx < x + w; gx += 16) g.fill(gx, y, gx + 1, y + h, (gx - x) % 64 == 0 ? 0x30FFFFFF : 0x14FFFFFF);
        for (int gy = y + 16; gy < y + h; gy += 16) g.fill(x, gy, x + w, gy + 1, (gy - y) % 64 == 0 ? 0x30FFFFFF : 0x14FFFFFF);
        for (int k = 0, tx = x + 64; tx < x + w - 8; tx += 64, k++) {
            g.fill(tx, y, tx + 1, y + 6, t.accent());
            g.fill(tx, y + h - 6, tx + 1, y + h, t.accent());
        }
        text(g, tr, "SECTION A-A  /  " + i.name(), x + 14, y + 12, t.text());
        int bw = 156, bh = 38, bx = x + w - bw - 12, by = y + h - bh - 12;
        g.fill(bx, by, bx + bw, by + bh, 0x90061630);
        UiUtil.outline(g, bx, by, bw, bh, t.accent());
        g.fill(bx, by + 19, bx + bw, by + 20, t.accent());
        g.drawText(tr, tr.trimToWidth(i.name(), bw - 10), bx + 5, by + 6, t.text(), false);
        g.drawText(tr, "SCALE 1:1  " + i.src(), bx + 5, by + 25, t.dim(), false);
        text(g, tr, stamp(), x + 14, y + h - 22, t.dim());
    }

    private static void neon(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        int a = t.accent();
        int pulse = 0x60 + (int) ((Math.sin(now / 450.0) + 1) * 0x28);
        int sweep = x + (int) ((now / 9) % Math.max(1, w));
        g.fill(sweep, y, sweep + 1, y + h, 0x30FF2BD6);
        g.fill(sweep - 3, y, sweep, y + h, 0x10FF2BD6);
        brackets(g, x + 8, y + 8, w - 16, h - 16, 18, (pulse << 24) | (a & 0xFFFFFF));
        brackets(g, x + 9, y + 9, w - 18, h - 18, 18, 0x302BFFD0);
        String name = "▌" + i.name();
        g.drawText(tr, name, x + 19, y + 17, 0x60FF2BD6, false);
        g.drawText(tr, name, x + 17, y + 15, 0x602BFFD0, false);
        text(g, tr, name, x + 18, y + 16, flick(t, now, 0xFFFFE6FA));
        textR(g, tr, "● LIVE", x + w - 18, y + 16, t.good());
        text(g, tr, stamp(), x + 18, y + h - 24, t.dim());
    }

    private static int heat(float v) {
        float[][] c = {{5, 0, 31}, {89, 0, 140}, {217, 26, 51}, {255, 140, 0}, {255, 242, 77}, {255, 255, 255}};
        float s = Math.max(0f, Math.min(1f, v)) * 5f;
        int k = Math.min(4, (int) s);
        float f = s - k;
        int r = (int) (c[k][0] + (c[k + 1][0] - c[k][0]) * f);
        int gg = (int) (c[k][1] + (c[k + 1][1] - c[k][1]) * f);
        int b = (int) (c[k][2] + (c[k + 1][2] - c[k][2]) * f);
        return 0xFF000000 | r << 16 | gg << 8 | b;
    }

    private static void thermal(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        int bh = Math.min(h - 60, 120), bx = x + w - 22, by = y + (h - bh) / 2;
        for (int k = 0; k < bh; k++) g.fill(bx, by + k, bx + 8, by + k + 1, heat(1f - k / (float) bh));
        UiUtil.outline(g, bx - 1, by - 1, 10, bh + 2, 0xFFFFFFFF);
        g.drawText(tr, "42°", bx - 22, by - 4, 0xFFFFFFFF, true);
        g.drawText(tr, "18°", bx - 22, by + bh - 4, 0xFFFFFFFF, true);
        int cx = x + w / 2, cy = y + h / 2;
        g.fill(cx - 14, cy, cx - 4, cy + 1, 0xFFFFFFFF); g.fill(cx + 4, cy, cx + 14, cy + 1, 0xFFFFFFFF);
        g.fill(cx, cy - 14, cx + 1, cy - 4, 0xFFFFFFFF); g.fill(cx, cy + 4, cx + 1, cy + 14, 0xFFFFFFFF);
        double temp = 35.5 + 2.0 * Math.sin(now / 900.0) + 0.3 * Math.sin(now / 110.0);
        text(g, tr, String.format("%.1f°C", temp), cx + 10, cy - 16, 0xFFFFFFFF);
        text(g, tr, "THERMAL  " + i.name(), x + 14, y + 14, 0xFFFFFFFF);
        text(g, tr, stamp(), x + 14, y + h - 22, 0xFFFFE8D0);
    }

    private static void hazard(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        int off = (int) ((now / 70) % 24);
        for (int bar = 0; bar < 2; bar++) {
            int by = bar == 0 ? y : y + h - 9;
            g.fill(x, by, x + w, by + 9, 0xFF0A0A0A);
            for (int row = 0; row < 9; row++)
                for (int sx = x - 30 + off - row; sx < x + w; sx += 24)
                    g.fill(Math.max(x, sx), by + row, Math.min(x + w, sx + 12), by + row + 1, t.accent());
        }
        text(g, tr, "CAUTION  " + i.name(), x + 14, y + 16, t.text());
        textR(g, tr, "ZONE " + i.src(), x + w - 14, y + 16, t.accent());
        text(g, tr, stamp(), x + 14, y + h - 24, t.dim());
    }

    private static void arctic(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        g.fillGradient(x, y, x + w, y + 34, 0x60FFFFFF, 0x00FFFFFF);
        g.fillGradient(x, y + h - 34, x + w, y + h, 0x00FFFFFF, 0x60FFFFFF);
        for (int k = 0; k < 40; k++) {
            Random r = new Random(k * 7919L);
            int sx = r.nextInt(w), base = r.nextInt(h), speed = 20 + r.nextInt(30);
            int yy = y + (int) ((base + now * speed / 1000.0) % h);
            int xx = x + (sx + (int) (Math.sin(now / 1000.0 + k) * 6) + w) % w;
            g.fill(xx, yy, xx + 2, yy + 2, 0xC0FFFFFF);
        }
        text(g, tr, "❄ " + i.name(), x + 14, y + 14, 0xFFFFFFFF);
        textR(g, tr, "-12°C", x + w - 14, y + 14, 0xFFE0F0FF);
        text(g, tr, stamp(), x + 14, y + h - 22, 0xFFE0F0FF);
    }

    private static void pixel(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        int a = t.accent();
        for (int cx : new int[]{x + 4, x + w - 10}) for (int cy : new int[]{y + 4, y + h - 10}) g.fill(cx, cy, cx + 6, cy + 6, a);
        text(g, tr, "1UP  " + i.name().toUpperCase(), x + 16, y + 14, a);
        long sec = (now / 1000) % 86400;
        text(g, tr, String.format("TIME %02d:%02d:%02d", sec / 3600, sec / 60 % 60, sec % 60), x + 16, y + h - 24, t.text());
        int lit = 4 + ((now / 700) % 4 == 0 ? 0 : 1);
        text(g, tr, "SIGNAL", x + w - 16 - 5 * 9 - tr.getWidth("SIGNAL") - 6, y + 14, t.text());
        for (int k = 0; k < 5; k++)
            g.fill(x + w - 16 - (5 - k) * 9, y + 14, x + w - 16 - (5 - k) * 9 + 7, y + 22, k < lit ? t.good() : 0x60FFFFFF);
    }
}
