package com.cameramonitor.data;

import java.util.*;

/** Локальные метаданные. Состав групп определяется названиями голов в мире, здесь — только пометки игрока. */
public final class Model {
    private Model() {}

    public static class CamMeta {
        public String alias = "";
        public boolean favorite;
        public boolean hidden;
        /** Сохраняемое увеличение (1 = без зума). */
        public float zoom = 1f;
    }

    public static class TagMeta {
        public Map<Integer, CamMeta> cams = new LinkedHashMap<>();
        /** Пользовательский порядок камер (индексы). Не вошедшие идут после по возрастанию. */
        public List<Integer> order = new ArrayList<>();

        public CamMeta cam(int idx) {
            return cams.computeIfAbsent(idx, k -> new CamMeta());
        }
    }

    public static class WorldData {
        public Map<String, TagMeta> tags = new LinkedHashMap<>();
        /** Последняя просмотренная камера по ключу монитора: «тег#индекс». */
        public Map<String, String> last = new HashMap<>();
        /** Группы, созданные в интерфейсе, но ещё без голов. */
        public List<String> drafts = new ArrayList<>();

        public TagMeta tag(String tag) {
            return tags.computeIfAbsent(tag, k -> new TagMeta());
        }

        public void sanitize() {
            if (tags == null) tags = new LinkedHashMap<>();
            if (last == null) last = new HashMap<>();
            if (drafts == null) drafts = new ArrayList<>();
            for (TagMeta t : tags.values()) {
                if (t.cams == null) t.cams = new LinkedHashMap<>();
                if (t.order == null) t.order = new ArrayList<>();
            }
        }
    }
}
