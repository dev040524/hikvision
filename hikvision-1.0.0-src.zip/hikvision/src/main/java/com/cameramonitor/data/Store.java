package com.cameramonitor.data;

import com.cameramonitor.CameraMonitorClient;
import com.cameramonitor.data.Model.WorldData;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Хранилище данных для текущего мира/сервера (только на клиенте). */
public final class Store {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static WorldData data = new WorldData();
    private static Path file;
    private static boolean dirty;

    private Store() {}

    public static WorldData get() { return data; }

    public static void markDirty() { dirty = true; }

    public static boolean isDirty() { return dirty; }

    public static void load(MinecraftClient c) {
        try {
            Path dir = FabricLoader.getInstance().getConfigDir().resolve("cameramonitor");
            Files.createDirectories(dir);
            file = dir.resolve(worldKey(c) + ".json");
            data = new WorldData();
            if (Files.exists(file)) {
                try (Reader r = Files.newBufferedReader(file)) {
                    WorldData d = GSON.fromJson(r, WorldData.class);
                    if (d != null) data = d;
                }
            }
        } catch (Exception e) {
            CameraMonitorClient.LOG.warn("Failed to load camera data", e);
            data = new WorldData();
        }
        data.sanitize();
        dirty = false;
    }

    public static void save() {
        if (file == null) return;
        try (Writer w = Files.newBufferedWriter(file)) {
            GSON.toJson(data, w);
            dirty = false;
        } catch (Exception e) {
            CameraMonitorClient.LOG.warn("Failed to save camera data", e);
        }
    }

    private static String worldKey(MinecraftClient c) {
        String raw;
        if (c.getServer() != null) raw = "sp_" + c.getServer().getSaveProperties().getLevelName();
        else if (c.getCurrentServerEntry() != null) raw = "mp_" + c.getCurrentServerEntry().address;
        else raw = "unknown";
        return raw.replaceAll("[^a-zA-Z0-9._-]", "_");
    }
}
