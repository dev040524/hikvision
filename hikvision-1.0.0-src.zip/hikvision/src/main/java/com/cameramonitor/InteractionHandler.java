package com.cameramonitor;

import com.cameramonitor.ui.MonitorScreen;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.world.World;

public final class InteractionHandler {
    private InteractionHandler() {}

    public static void open(String rawTags) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.currentScreen instanceof MonitorScreen) return;
        Sfx.open();
        mc.setScreen(new MonitorScreen(rawTags));
    }

    /** ПКМ по воздуху с головой Monitor в руке — открыть интерфейс. */
    public static ActionResult onUseItem(PlayerEntity player, World world, Hand hand) {
        if (!world.isClient()) return ActionResult.PASS;
        Heads.Parsed p = Heads.parse(player.getStackInHand(hand));
        if (p.kind() == Heads.Kind.MONITOR) {
            open(p.tag());
            return ActionResult.SUCCESS;
        }
        return ActionResult.PASS;
    }

    public static ActionResult onUseBlock(PlayerEntity player, World world, Hand hand, BlockHitResult hit) {
        if (!world.isClient()) return ActionResult.PASS;

        // ПКМ по установленному монитору (без Shift) — смотреть камеры. Монитор распознаётся по названию головы.
        if (!player.isSneaking()) {
            BlockEntity be = world.getBlockEntity(hit.getBlockPos());
            if (be instanceof SkullBlockEntity sk && sk.customName != null) {
                Heads.Parsed p = Heads.parse(sk.customName.getString());
                if (p.kind() == Heads.Kind.MONITOR) {
                    open(p.tag());
                    return ActionResult.SUCCESS;
                }
            }
        }
        ItemStack s = player.getStackInHand(hand);
        Heads.Parsed p = Heads.parse(s);
        if (p.kind() == Heads.Kind.MONITOR && ModConfig.get().placeRequiresSneak && !player.isSneaking()) {
            open(p.tag());
            return ActionResult.SUCCESS;
        }
        return ActionResult.PASS;
    }
}
