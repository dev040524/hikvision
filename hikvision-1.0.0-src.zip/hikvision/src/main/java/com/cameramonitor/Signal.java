package com.cameramonitor;

import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Arm;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Положение и направление живой камеры: блок, голова существа или его рука. */
public record Signal(boolean ok, Vec3d pos, float yaw, float pitch, String src) {
    private static final Signal OFFLINE = new Signal(false, Vec3d.ZERO, 0, 0, "");

    public static Signal resolve(Cameras.Live l, World w, float delta) {
        if (l == null) return OFFLINE;
        return l.src() == Cameras.Src.BLOCK ? fromBlock(l.pos(), w) : fromEntity(l, w, delta);
    }

    private static Signal fromBlock(BlockPos p, World w) {
        BlockState st = w.getBlockState(p);
        if (!(st.getBlock() instanceof AbstractSkullBlock)) return OFFLINE;
        float yaw = 0;
        boolean wall = false;
        if (st.contains(Properties.ROTATION)) {
            // Лицевая сторона напольной головы смотрит противоположно ROTATION*22.5° — поэтому +180.
            yaw = st.get(Properties.ROTATION) * 22.5f + 180f;
        } else if (st.contains(Properties.HORIZONTAL_FACING)) {
            wall = true;
            Direction d = st.get(Properties.HORIZONTAL_FACING);
            yaw = switch (d) {
                case WEST -> 90f;
                case NORTH -> 180f;
                case EAST -> 270f;
                default -> 0f;
            };
        }
        double r = Math.toRadians(yaw);
        Vec3d fwd = new Vec3d(-Math.sin(r), 0, Math.cos(r));
        Vec3d base = new Vec3d(p.getX() + 0.5, p.getY() + (wall ? 0.5 : 0.32), p.getZ() + 0.5);
        return new Signal(true, base.add(fwd.multiply(0.32)), yaw, 0f, "BLOCK");
    }

    private static Signal fromEntity(Cameras.Live l, World w, float delta) {
        Entity e = w.getEntityById(l.entityId());
        if (!(e instanceof LivingEntity le)) return OFFLINE;
        Cameras.Src s = Cameras.srcOf(le, l.tag(), l.index());
        if (s == null) return OFFLINE; // камеру сняли или убрали из рук

        float yaw = le instanceof PlayerEntity ? le.getYaw(delta) : le.getHeadYaw();
        float pitch = le.getPitch(delta);
        Vec3d eye = le.getCameraPosVec(delta);
        double r = Math.toRadians(yaw);
        Vec3d fwd = new Vec3d(-Math.sin(r), 0, Math.cos(r));
        if (s == Cameras.Src.HEAD) {
            return new Signal(true, eye.add(fwd.multiply(0.4)), yaw, pitch, "HEAD");
        }
        boolean right = (s == Cameras.Src.MAIN) == (le.getMainArm() == Arm.RIGHT);
        Vec3d rightVec = new Vec3d(-Math.cos(r), 0, -Math.sin(r));
        Vec3d pos = eye.add(fwd.multiply(0.45)).add(rightVec.multiply(right ? 0.3 : -0.3)).add(0, -0.3, 0);

        // Покачивание в такт ходьбе (анимация конечностей, как у руки).
        float limbPos = le.limbAnimator.getAnimationProgress(delta);
        float limbSpeed = Math.min(1f, le.limbAnimator.getSpeed());
        double swing = Math.cos(limbPos * 0.6662f) * limbSpeed;
        double sway = Math.sin(limbPos * 0.6662f * 0.5f) * limbSpeed;
        pos = pos.add(0, Math.abs(swing) * 0.06, 0).add(rightVec.multiply(sway * 0.05));
        return new Signal(true, pos, yaw + (float) (sway * 2.0), pitch + (float) (swing * 3.0), "HAND");
    }
}
