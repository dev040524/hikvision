package com.cameramonitor;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Схема имён (задаётся в наковальне):
 * <pre>
 *   Camera: lobby 2      — камера с номером 2 в группе «lobby»
 *   Monitor: lobby, door — монитор, показывающий группы «lobby» и «door»
 *   Monitor              — монитор, показывающий все группы
 * </pre>
 */
public final class Heads {
    public enum Kind { NONE, MONITOR, CAMERA }

    public record Parsed(Kind kind, String tag, int index) {
        public static final Parsed NONE = new Parsed(Kind.NONE, "", 0);
    }

    private Heads() {}

    public static Parsed parse(ItemStack s) {
        if (s == null || s.isEmpty() || !s.isOf(Items.PLAYER_HEAD)) return Parsed.NONE;
        Text n = s.get(DataComponentTypes.CUSTOM_NAME);
        return n == null ? Parsed.NONE : parse(n.getString());
    }

    public static Kind kindOf(ItemStack s) {
        return parse(s).kind();
    }

    public static Parsed parse(String raw) {
        if (raw == null) return Parsed.NONE;
        String name = raw.trim();
        ModConfig cfg = ModConfig.get();
        String rest = strip(name, cfg.cameraPrefix);
        if (rest != null) {
            int idx = 0;
            String tag = rest;
            int sp = rest.lastIndexOf(' ');
            String last = sp < 0 ? rest : rest.substring(sp + 1);
            if (last.matches("\\d{1,6}")) {
                idx = Integer.parseInt(last);
                tag = sp < 0 ? "" : rest.substring(0, sp).trim();
            }
            return new Parsed(Kind.CAMERA, tag.toLowerCase(Locale.ROOT), idx);
        }
        rest = strip(name, cfg.monitorPrefix);
        if (rest != null) return new Parsed(Kind.MONITOR, rest.toLowerCase(Locale.ROOT), 0);
        return Parsed.NONE;
    }

    /** Возвращает остаток после префикса (без «:» и пробелов) или null, если префикса нет. */
    private static String strip(String name, String prefix) {
        if (prefix == null || prefix.isBlank()) return null;
        if (name.length() < prefix.length() || !name.regionMatches(true, 0, prefix, 0, prefix.length())) return null;
        String rest = name.substring(prefix.length());
        if (!rest.isEmpty() && rest.charAt(0) != ':' && rest.charAt(0) != ' ') return null;
        rest = rest.trim();
        if (rest.startsWith(":")) rest = rest.substring(1).trim();
        return rest;
    }

    public static List<String> splitTags(String raw) {
        List<String> out = new ArrayList<>();
        if (raw == null) return out;
        for (String p : raw.split(",")) {
            String t = p.trim().toLowerCase(Locale.ROOT);
            if (!t.isEmpty() && !out.contains(t)) out.add(t);
        }
        return out;
    }

    public static String cameraName(String tag, int idx) {
        return ModConfig.get().cameraPrefix + ": " + (tag.isEmpty() ? "" : tag + " ") + idx;
    }

    public static String monitorName(List<String> tags) {
        return ModConfig.get().monitorPrefix + (tags.isEmpty() ? "" : ": " + String.join(", ", tags));
    }

    public static String dimOf(World w) {
        return w.getRegistryKey().getValue().toString();
    }
}
