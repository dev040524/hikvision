package com.cameramonitor;

import com.cameramonitor.data.Store;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CameraMonitorClient implements ClientModInitializer {
    public static final String MOD_ID = "cameramonitor";
    public static final Logger LOG = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        ModConfig.load();
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> Store.load(client));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            Store.save();
            Cameras.clear();
        });
        ClientTickEvents.END_CLIENT_TICK.register(Cameras::tick);
        UseItemCallback.EVENT.register(InteractionHandler::onUseItem);
        UseBlockCallback.EVENT.register(InteractionHandler::onUseBlock);
    }
}
