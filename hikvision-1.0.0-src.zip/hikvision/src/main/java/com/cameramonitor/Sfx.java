package com.cameramonitor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundManager;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/**
 * Звуки мода. Собственные файлы лежат в assets/cameramonitor/sounds, громкость каждого задаётся в sounds.json
 * (там же их можно подменить ресурс-паком).
 */
public final class Sfx {
    private static final SoundEvent SWITCH = SoundEvent.of(Identifier.of("cameramonitor", "switch"));
    private static final SoundEvent OPEN = SoundEvent.of(Identifier.of("cameramonitor", "open"));
    private static final SoundEvent ALERT = SoundEvent.of(Identifier.of("cameramonitor", "alert"));
    private static final SoundEvent NOSIGNAL = SoundEvent.of(Identifier.of("cameramonitor", "nosignal"));

    private static final SoundEvent SHUTTER = SoundEvent.of(Identifier.of("cameramonitor", "shutter"));
    private static final SoundEvent CLOSE = SoundEvent.of(Identifier.of("cameramonitor", "close"));
    private static final SoundEvent AUTO_ON = SoundEvent.of(Identifier.of("cameramonitor", "auto_on"));
    private static final SoundEvent AUTO_OFF = SoundEvent.of(Identifier.of("cameramonitor", "auto_off"));
    private static final SoundEvent ZOOM = SoundEvent.of(Identifier.of("cameramonitor", "zoom"));

    private static PositionedSoundInstance noSignalInstance;
    private static long lastZoom;

    private Sfx() {}

    private static boolean on() { return ModConfig.get().sounds; }

    private static SoundManager sm() { return MinecraftClient.getInstance().getSoundManager(); }

    /** Переключение камеры. */
    public static void noise() {
        if (on()) sm().play(PositionedSoundInstance.ui(SWITCH, 1f, 1f));
    }

    /** Открытие монитора. */
    public static void open() {
        if (on()) sm().play(PositionedSoundInstance.ui(OPEN, 1f, 1f));
    }

    /** Детектор движения (очень тихий, громкость 4% — в sounds.json). */
    public static void alert() {
        if (on()) sm().play(PositionedSoundInstance.ui(ALERT, 1f, 1f));
    }

    public static void shutter() { play(SHUTTER); }

    public static void close() { play(CLOSE); }

    public static void auto(boolean enabled) { play(enabled ? AUTO_ON : AUTO_OFF); }

    /** Тик зума; не чаще раза в 90 мс, чтобы Q/E не превращались в трель. */
    public static void zoom() {
        long now = System.currentTimeMillis();
        if (now - lastZoom < 90) return;
        lastZoom = now;
        play(ZOOM);
    }

    private static void play(SoundEvent e) {
        if (on()) sm().play(PositionedSoundInstance.ui(e, 1f, 1f));
    }

    /**
     * Шум «нет сигнала»: пока камера недоступна, проигрывается и перезапускается по окончании (зацикленно).
     * Вызывать каждый кадр; false — остановить.
     */
    public static void noSignal(boolean wanted) {
        SoundManager m = sm();
        if (wanted && on()) {
            if (noSignalInstance == null || !m.isPlaying(noSignalInstance)) {
                noSignalInstance = PositionedSoundInstance.ui(NOSIGNAL, 1f, 1f);
                m.play(noSignalInstance);
            }
        } else if (noSignalInstance != null) {
            m.stop(noSignalInstance);
            noSignalInstance = null;
        }
    }
}
