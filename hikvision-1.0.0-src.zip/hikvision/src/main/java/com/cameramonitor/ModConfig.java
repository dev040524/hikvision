package com.cameramonitor;

import com.cameramonitor.ui.Theme;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public class ModConfig {
    public String theme = "classic";
    public double viewportScale = 0.85;
    /** Непрозрачность фона интерфейса (0 — полностью прозрачный, 1 — сплошной). */
    public double backgroundOpacity = 0.9;
    public boolean scanlines = true;
    public boolean useShader = true;
    public boolean sounds = true;
    public boolean showCoords = false;
    public boolean openLastCamera = true;
    public int autoCycleSeconds = 5;
    public int lookRange = 60;
    public boolean placeRequiresSneak = true;
    /** Камеры на голове и в руках существ. */
    public boolean carriedCameras = true;
    /** Ночное видение: усиление света, когда в зоне камеры темно (нужен шейдер). */
    public boolean nightVision = true;
    /** Дальше этого расстояния (в блоках) сигнал слабеет; в 1,5 раза дальше — пропадает. 0 — без ограничения. */
    public int signalRange = 128;
    public boolean motionAlerts = true;
    public int motionRadius = 8;
    public boolean motionMobs = false;
    /** Префиксы имён голов (меняются только в файле конфига). */
    public String cameraPrefix = "Camera";
    public String monitorPrefix = "Monitor";

    private static ModConfig INSTANCE = new ModConfig();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("cameramonitor.json");
    }

    public static ModConfig get() {
        return INSTANCE;
    }

    public static void load() {
        Path p = path();
        if (Files.exists(p)) {
            try (Reader r = Files.newBufferedReader(p)) {
                ModConfig c = GSON.fromJson(r, ModConfig.class);
                if (c != null) INSTANCE = c;
            } catch (Exception e) {
                CameraMonitorClient.LOG.warn("Failed to read config", e);
            }
        }
        INSTANCE.sanitize();
        save();
    }

    public static void save() {
        try (Writer w = Files.newBufferedWriter(path())) {
            GSON.toJson(INSTANCE, w);
        } catch (Exception e) {
            CameraMonitorClient.LOG.warn("Failed to write config", e);
        }
    }

    private void sanitize() {
        theme = Theme.byId(theme).id();
        viewportScale = Math.max(0.5, Math.min(1.0, viewportScale));
        lookRange = Math.max(0, Math.min(90, lookRange));
        backgroundOpacity = Math.max(0.0, Math.min(1.0, backgroundOpacity));
        autoCycleSeconds = Math.max(1, Math.min(120, autoCycleSeconds));
        motionRadius = Math.max(2, Math.min(32, motionRadius));
        signalRange = Math.max(0, Math.min(1024, signalRange));
        if (cameraPrefix == null || cameraPrefix.isBlank()) cameraPrefix = "Camera";
        if (monitorPrefix == null || monitorPrefix.isBlank()) monitorPrefix = "Monitor";
    }
}
