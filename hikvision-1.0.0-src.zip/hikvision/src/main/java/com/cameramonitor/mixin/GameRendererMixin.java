package com.cameramonitor.mixin;

import com.cameramonitor.CameraView;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Зум камеры: уменьшает угол обзора. Необязательный миксин — без него зума просто нет. */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true, require = 0)
    private void cameramonitor$zoom(CallbackInfoReturnable<Float> cir) {
        CameraView v = CameraView.INSTANCE;
        if (v.isActive() && v.zoom() > 1.001f) {
            double half = Math.tan(Math.toRadians(cir.getReturnValue()) / 2.0) / v.zoom();
            cir.setReturnValue((float) Math.toDegrees(2.0 * Math.atan(half)));
        }
    }
}
