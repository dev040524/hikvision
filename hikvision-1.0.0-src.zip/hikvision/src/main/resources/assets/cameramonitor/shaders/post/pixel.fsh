#version 150

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

// Params: x = число уровней цвета, y = затемнение, z = пикселизация (0..1), w = виньетка
layout(std140) uniform FeedConfig {
    vec4 Params;
    vec4 Tint;
};

in vec2 texCoord;
out vec4 fragColor;

void main() {
    float cells = mix(96.0, InSize.x, Params.z);
    vec2 block = vec2(cells, cells * InSize.y / InSize.x);
    vec2 uv = (floor(texCoord * block) + 0.5) / block;
    vec3 c = texture(InSampler, uv).rgb;
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(vec3(l), c, 1.3);
    c = floor(c * Params.x + 0.5) / Params.x;
    c *= 1.0 - Params.y;
    float d = distance(texCoord, vec2(0.5));
    c *= 1.0 - Params.w * smoothstep(0.45, 0.95, d);
    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
