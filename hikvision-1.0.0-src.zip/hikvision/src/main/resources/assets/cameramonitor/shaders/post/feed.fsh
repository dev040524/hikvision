#version 150

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

// Params: x = серость (0..1), y = затемнение, z = пикселизация (1 = нет), w = виньетка
// Tint:   rgb = множитель цвета, a = сила тонировки
layout(std140) uniform FeedConfig {
    vec4 Params;
    vec4 Tint;
};

in vec2 texCoord;

out vec4 fragColor;

void main() {
    vec2 uv = texCoord;
    if (Params.z < 0.999) {
        float cells = mix(96.0, InSize.x, Params.z);
        vec2 block = vec2(cells, cells * InSize.y / InSize.x);
        uv = (floor(uv * block) + 0.5) / block;
    }
    vec3 c = texture(InSampler, uv).rgb;
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(c, vec3(l), Params.x);
    c = mix(c, c * Tint.rgb, Tint.a);
    c *= 1.0 - Params.y;
    float d = distance(texCoord, vec2(0.5));
    c *= 1.0 - Params.w * smoothstep(0.35, 0.9, d);
    fragColor = vec4(c, 1.0);
}
