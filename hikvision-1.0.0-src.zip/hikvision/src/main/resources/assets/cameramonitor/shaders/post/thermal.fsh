#version 150

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

// Params: y = затемнение, w = виньетка
layout(std140) uniform FeedConfig {
    vec4 Params;
    vec4 Tint;
};

in vec2 texCoord;
out vec4 fragColor;

vec3 palette(float v) {
    vec3 c0 = vec3(0.02, 0.00, 0.12);
    vec3 c1 = vec3(0.35, 0.00, 0.55);
    vec3 c2 = vec3(0.85, 0.10, 0.20);
    vec3 c3 = vec3(1.00, 0.55, 0.00);
    vec3 c4 = vec3(1.00, 0.95, 0.30);
    vec3 c5 = vec3(1.00);
    float t = clamp(v, 0.0, 1.0) * 5.0;
    if (t < 1.0) return mix(c0, c1, t);
    if (t < 2.0) return mix(c1, c2, t - 1.0);
    if (t < 3.0) return mix(c2, c3, t - 2.0);
    if (t < 4.0) return mix(c3, c4, t - 3.0);
    return mix(c4, c5, t - 4.0);
}

void main() {
    vec3 c = texture(InSampler, texCoord).rgb;
    float l = smoothstep(0.04, 0.95, dot(c, vec3(0.299, 0.587, 0.114)));
    vec3 o = palette(l) * (1.0 - Params.y);
    float d = distance(texCoord, vec2(0.5));
    o *= 1.0 - Params.w * smoothstep(0.4, 0.95, d);
    fragColor = vec4(o, 1.0);
}
