#version 150

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

// Params: x = сила линий, y = затемнение, w = виньетка; Tint.rgb = цвет «синьки»
layout(std140) uniform FeedConfig {
    vec4 Params;
    vec4 Tint;
};

in vec2 texCoord;
out vec4 fragColor;

float lum(vec2 uv) {
    return dot(texture(InSampler, uv).rgb, vec3(0.299, 0.587, 0.114));
}

void main() {
    vec2 px = 1.5 / InSize;
    float a = lum(texCoord + vec2(-px.x, -px.y));
    float b = lum(texCoord + vec2(0.0, -px.y));
    float c = lum(texCoord + vec2(px.x, -px.y));
    float d = lum(texCoord + vec2(-px.x, 0.0));
    float f = lum(texCoord + vec2(px.x, 0.0));
    float g = lum(texCoord + vec2(-px.x, px.y));
    float h = lum(texCoord + vec2(0.0, px.y));
    float i = lum(texCoord + vec2(px.x, px.y));
    float gx = -a - 2.0 * d - g + c + 2.0 * f + i;
    float gy = -a - 2.0 * b - c + g + 2.0 * h + i;
    float e = clamp(length(vec2(gx, gy)) * Params.x, 0.0, 1.0);
    float base = lum(texCoord);
    vec3 bg = Tint.rgb * (0.5 + 0.5 * base);
    vec3 o = mix(bg, vec3(0.92, 0.97, 1.0), e) * (1.0 - Params.y);
    float dist = distance(texCoord, vec2(0.5));
    o *= 1.0 - Params.w * smoothstep(0.4, 0.95, dist);
    fragColor = vec4(o, 1.0);
}
