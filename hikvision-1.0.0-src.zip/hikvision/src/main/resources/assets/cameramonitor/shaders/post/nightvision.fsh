#version 150

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

// Params: x = усиление света, y = смещение, w = виньетка; Tint.rgb = цвет «ночного видения»
layout(std140) uniform FeedConfig {
    vec4 Params;
    vec4 Tint;
};

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec3 c = texture(InSampler, texCoord).rgb;
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    l = clamp(l * Params.x + Params.y, 0.0, 1.0);
    l = pow(l, 0.6);
    float n = fract(sin(dot(texCoord * InSize, vec2(12.9898, 78.233))) * 43758.5453);
    l = clamp(l + (n - 0.5) * 0.12, 0.0, 1.0);
    vec3 o = Tint.rgb * l;
    float d = distance(texCoord, vec2(0.5));
    o *= 1.0 - Params.w * smoothstep(0.35, 0.9, d);
    fragColor = vec4(o, 1.0);
}
