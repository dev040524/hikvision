package com.cameramonitor.ui;

import net.minecraft.client.gui.DrawContext;

import java.util.Random;

/** Капли дождя и пыль на стекле объектива (для блочных камер). Всё движется плавно по времени. */
public final class LensEffects {
    private LensEffects() {}

    private static void ellipse(DrawContext g, int cx, int cy, int rx, int ry, int color) {
        if (rx < 1 || ry < 1) return;
        for (int dy = -ry; dy <= ry; dy++) {
            double f = 1.0 - (dy * dy) / (double) (ry * ry);
            int hw = (int) (rx * Math.sqrt(Math.max(0, f)));
            if (hw > 0) g.fill(cx - hw, cy + dy, cx + hw, cy + dy + 1, color);
        }
    }

    /** rain 0..1 — сила дождя в точке камеры, dust 0..1 — запылённость стекла. */
    public static void draw(DrawContext g, int x, int y, int w, int h, float rain, float dust, String seedKey, long now) {
        if (dust > 0.01f) {
            Random r = new Random(seedKey.hashCode() * 31L + 7);
            int n = (int) (dust * w * h / 900f);
            for (int k = 0; k < n; k++) {
                int px = x + r.nextInt(Math.max(1, w - 2)), py = y + r.nextInt(Math.max(1, h - 2));
                int a = (int) ((0x14 + r.nextInt(0x34)) * Math.min(1f, dust + 0.3f));
                int s = r.nextInt(5) == 0 ? 2 : 1;
                g.fill(px, py, px + s, py + s, (a << 24) | 0xC8C0B0);
            }
            for (int k = 0; k < 5; k++) {
                int cx = x + r.nextInt(Math.max(1, w)), cy = y + r.nextInt(Math.max(1, h));
                int a = (int) ((0x06 + r.nextInt(0x08)) * dust * 2f);
                ellipse(g, cx, cy, 16 + r.nextInt(30), 8 + r.nextInt(18), (a << 24) | 0xD0C8B8);
            }
        }
        if (rain > 0.05f) {
            int n = (int) (rain * w * h / 7000f);
            for (int i = 0; i < n; i++) {
                Random r = new Random(i * 9176L + 13);
                int life = 7000 + r.nextInt(9000);
                double ph = ((now + r.nextInt(life)) % life) / (double) life;
                int cx = x + 4 + r.nextInt(Math.max(1, w - 8));
                int y0 = y + 4 + r.nextInt(Math.max(1, h * 3 / 4));
                int rad = 2 + r.nextInt(5);
                double slide = ph > 0.6 ? (ph - 0.6) / 0.4 : 0;
                int cy = y0 + (int) (slide * slide * h * 0.18);
                double fade = Math.min(1.0, Math.min(ph / 0.05, (1.0 - ph) / 0.05));
                int alpha = (int) (fade * 0xFF);
                if (alpha < 8) continue;
                if (slide > 0) g.fill(cx, y0, cx + 1, cy, ((alpha * 0x18 / 0xFF) << 24) | 0xC8DCF0); // след капли
                ellipse(g, cx, cy, rad, (int) (rad * 1.35), ((alpha * 0x30 / 0xFF) << 24) | 0xC8DCF0);
                g.fill(cx - rad / 2, cy + (int) (rad * 1.35) - 1, cx + rad / 2 + 1, cy + (int) (rad * 1.35), ((alpha * 0x30 / 0xFF) << 24)); // тёмный нижний край
                g.fill(cx - rad / 2, cy - rad / 2, cx - rad / 2 + 2, cy - rad / 2 + 2, ((alpha * 0x90 / 0xFF) << 24) | 0xFFFFFF);  // блик
            }
        }
    }
}
