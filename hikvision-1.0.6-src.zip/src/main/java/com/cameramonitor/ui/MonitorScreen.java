package com.cameramonitor.ui;

import com.cameramonitor.CameraView;
import com.cameramonitor.Cameras;
import com.cameramonitor.Heads;
import com.cameramonitor.ModConfig;
import com.cameramonitor.PostFx;
import com.cameramonitor.Sfx;
import com.cameramonitor.Signal;
import com.cameramonitor.data.Model.CamMeta;
import com.cameramonitor.data.Store;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.ScreenshotRecorder;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * Интерфейс монитора. Групп нет: список камер — это ровно те головы, которые найдены в мире и чьи названия
 * подходят монитору (Monitor: тег1, тег2 — только эти теги; просто Monitor — все камеры).
 */
public class MonitorScreen extends Screen {
    private enum Mode { VIEW, SETUP }

    private record Entry(String tag, int idx, String key, CamMeta meta, String label) {}

    private static final int CELL = 18;

    private final List<String> monitorTags;
    private final String monitorKey;
    private Mode mode = Mode.VIEW;
    private String curKey = "";
    private boolean favOnly;
    private int listScroll, nameCounter;
    private String setupSig = "";

    // состояние просмотра
    private boolean enteredView, prevHud, fxApplied;
    private Perspective prevPerspective;
    private float lookYaw, lookPitch, lastDelta;
    private long lastNanos = System.nanoTime();
    private boolean prevL, prevR, prevC;
    private final boolean[] prevNum = new boolean[9];
    private Signal signal;
    private int weakLevel;
    private boolean night, tooFar;
    private float weak, lensRain;
    private long lightCheck;
    private boolean autoCycle, shotPending;
    private long lastSwitch = System.currentTimeMillis();

    // геометрия
    private int vx, vy, vw, vh;
    private int panelX, panelY, panelW, panelH, leftW, rightX, gridX, gridY;
    private final List<Entry> rowEntries = new ArrayList<>();
    private final List<Integer> rowYs = new ArrayList<>();
    private final boolean[] camSlot = new boolean[36];
    private ThemedButton prevBtn, nextBtn, favBtn, autoBtn, shotBtn;
    private Text status = Text.empty();
    private long statusUntil;

    public MonitorScreen(String rawTags) {
        super(Text.translatable("cameramonitor.title"));
        this.monitorTags = Heads.splitTags(rawTags);
        this.monitorKey = monitorTags.isEmpty() ? "*" : String.join(",", monitorTags);
        Cameras.refresh();
        if (ModConfig.get().openLastCamera) {
            String last = Store.get().last.get(monitorKey);
            if (last != null) curKey = last;
        } 
        if (entries(false).isEmpty()) mode = Mode.SETUP;
    }

    private static Text t(String k, Object... a) { return Text.translatable("cameramonitor." + k, a); }

    public List<String> monitorTags() { return monitorTags; }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float d) { /* без размытия — виден мир */ }

    // ------------------------------------------------------------ список камер (строго по названиям)

    private List<Entry> entries(boolean onlyFav) {
        Map<String, Entry> map = new LinkedHashMap<>();
        for (Cameras.Live l : Cameras.live()) {
            if (!monitorTags.isEmpty() && !monitorTags.contains(l.tag())) continue;
            if (map.containsKey(l.key())) continue;
            map.put(l.key(), new Entry(l.tag(), l.index(), l.key(), Store.get().tag(l.tag()).cam(l.index()),
                    Cameras.label(l.key(), l.tag(), l.index())));
        }
        // Выбранная камера, которая только что пропала (сняли, переименовали), остаётся в списке до переключения:
        // так видно «Нет сигнала», а не внезапная смена картинки.
        int h = curKey.lastIndexOf('#');
        if (!curKey.isEmpty() && h >= 0 && !map.containsKey(curKey)) {
            try {
                String tag = curKey.substring(0, h);
                int idx = Integer.parseInt(curKey.substring(h + 1));
                if (monitorTags.isEmpty() || monitorTags.contains(tag))
                    map.put(curKey, new Entry(tag, idx, curKey, Store.get().tag(tag).cam(idx), Cameras.label(curKey, tag, idx)));
            } catch (NumberFormatException ignored) {
            }
        }
        List<Entry> out = new ArrayList<>(map.values());
        out.sort(Comparator.comparing(Entry::tag).thenComparingInt(Entry::idx));
        if (onlyFav) out.removeIf(e -> !e.meta().favorite && !e.key().equals(curKey));
        return out;
    }

    private Entry current() {
        List<Entry> l = entries(favOnly);
        if (l.isEmpty()) return null;
        for (Entry e : l) if (e.key().equals(curKey)) return e;
        curKey = l.get(0).key();
        return l.get(0);
    }

    private int positionOf(List<Entry> l, String key) {
        for (int i = 0; i < l.size(); i++) if (l.get(i).key().equals(key)) return i;
        return 0;
    }

    private List<Entry> favorites() {
        List<Entry> r = entries(false);
        r.removeIf(e -> !e.meta().favorite);
        return r;
    }

    private int favNo(Entry e) {
        List<Entry> f = favorites();
        for (int i = 0; i < f.size(); i++) if (f.get(i).key().equals(e.key())) return i + 1;
        return 0;
    }

    private void jumpFav(int n) {
        List<Entry> f = favorites();
        if (n >= f.size()) {
            status(t("fav.none", n + 1));
            return;
        }
        curKey = f.get(n).key();
        resetLook();
        Sfx.noise();
        remember();
    }

    private void step(int d) {
        List<Entry> l = entries(favOnly);
        if (l.isEmpty()) return;
        curKey = l.get(((positionOf(l, curKey) + d) % l.size() + l.size()) % l.size()).key();
        resetLook();
        Sfx.noise();
        remember();
    }

    /** При переключении камеры берём её сохранённый осмотр (или центр, если запоминание выключено). */
    private void resetLook() {
        lastSwitch = System.currentTimeMillis();
        Entry c = current();
        if (c != null && ModConfig.get().rememberLook) {
            int range = ModConfig.get().lookRange;
            lookYaw = Math.max(-range, Math.min(range, c.meta().lookYaw));
            lookPitch = Math.max(-range / 2f, Math.min(range / 2f, c.meta().lookPitch));
        } else {
            lookYaw = 0;
            lookPitch = 0;
        }
    }

    /** Сохраняет текущий осмотр в пометках выбранной камеры. */
    private void saveLook() {
        Entry c = current();
        if (c == null || !ModConfig.get().rememberLook) return;
        if (Math.abs(c.meta().lookYaw - lookYaw) > 0.01f || Math.abs(c.meta().lookPitch - lookPitch) > 0.01f) {
            c.meta().lookYaw = lookYaw;
            c.meta().lookPitch = lookPitch;
            Store.markDirty();
        }
    }

    private void remember() {
        if (!curKey.isEmpty()) {
            Store.get().last.put(monitorKey, curKey);
            Store.markDirty();
        }
    }

    private void status(Text s) {
        status = s;
        statusUntil = System.currentTimeMillis() + 4000;
    }

    private String helperTag() {
        if (!monitorTags.isEmpty()) return monitorTags.get(0);
        Entry c = current();
        return c == null ? "" : c.tag();
    }

    private int nextIndex(String tag) {
        int max = 0;
        for (Cameras.Live l : Cameras.live()) if (l.tag().equals(tag)) max = Math.max(max, l.index());
        if (client != null && client.player != null)
            for (int s = 0; s < 36; s++) {
                Heads.Parsed p = Heads.parse(client.player.getInventory().getStack(s));
                if (p.kind() == Heads.Kind.CAMERA && p.tag().equals(tag)) max = Math.max(max, p.index());
            }
        return max + 1;
    }

    private void copyName(String text) {
        client.keyboard.setClipboard(text);
        status(t(text.length() > 50 ? "name.too_long" : "name.copied", text));
    }

    // ------------------------------------------------------------ жизненный цикл

    @Override
    protected void init() {
        rowEntries.clear();
        rowYs.clear();
        if (mode == Mode.VIEW) enterView(); else leaveView();
        buildTop();
        if (mode == Mode.VIEW) buildView(); else buildSetup();
    }

    private void enterView() {
        if (enteredView) return;
        prevHud = client.options.hudHidden;
        prevPerspective = client.options.getPerspective();
        client.options.hudHidden = true;
        client.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        night = false;
        weakLevel = 0;
        fxApplied = PostFx.apply(client, Theme.current().id(), 0);
        enteredView = true;
        resetLook();
        remember();
    }

    private void applyFx() {
        if (enteredView && fxApplied) fxApplied = PostFx.apply(client, night ? "nightvision" : Theme.current().id(), weakLevel);
    }

    /**
     * Выбор «глаз» рендера. Для камеры на голове/в руке камерой игры становится носитель в виде от первого лица:
     * игра сама ставит камеру в его глаза, а его модель (голова, руки, предмет) не рисуется — как при наблюдении
     * за игроком в режиме наблюдателя. Для блока камерой остаётся наш игрок с видом от третьего лица.
     */
    private void applyView(Entity carrier) {
        Entity want = carrier != null ? carrier : client.player;
        Perspective wp = carrier != null ? Perspective.FIRST_PERSON : Perspective.THIRD_PERSON_BACK;
        boolean changed = false;
        if (want != null && client.getCameraEntity() != want) {
            client.setCameraEntity(want);
            changed = true;
        }
        if (client.options.getPerspective() != wp) client.options.setPerspective(wp);
        if (changed) applyFx(); // смена камеры-сущности сбрасывает пост-эффект игры
    }

    private void leaveView() {
        Sfx.noSignal(false);
        CameraView.INSTANCE.deactivate();
        if (!enteredView) return;
        if (client.player != null && client.getCameraEntity() != client.player) client.setCameraEntity(client.player);
        client.options.hudHidden = prevHud;
        client.options.setPerspective(prevPerspective);
        if (fxApplied) PostFx.clear(client);
        fxApplied = false;
        enteredView = false;
    }

    @Override
    public void removed() {
        Sfx.close();
        leaveView();
        Store.save();
    }

    @Override
    public void tick() {
        if (mode == Mode.VIEW && client.player != null && client.player.hurtTime > 0) close();
    }

    // ------------------------------------------------------------ виджеты

    private ThemedButton btn(int x, int y, int w, int h, net.minecraft.text.Text label, Runnable r) {
        ThemedButton b = new ThemedButton(x, y, w, h, label, x0 -> r.run());
        addDrawableChild(b);
        return b;
    }

    private ThemedButton autoBtn(int[] cur, int maxX, int h, net.minecraft.text.Text label, Runnable r) {
        int w = textRenderer.getWidth(label) + 14;
        if (cur[0] + w > maxX && cur[0] > panelX + 8) {
            cur[0] = panelX + 6;
            cur[1] += h + 4;
        }
        ThemedButton b = btn(cur[0], cur[1], w, h, label, r);
        cur[0] += w + 4;
        return b;
    }

    private String monitorLabel() {
        return monitorTags.isEmpty() ? t("monitor.all").getString() : Heads.monitorName(monitorTags);
    }

    /** Одна компактная строка: [режим] [тема] [только избранное] название монитора … [закрыть]. */
    private void buildTop() {
        boolean view = mode == Mode.VIEW;
        btn(8, 3, 20, 18, Text.literal(view ? "⚙" : "▣"), () -> {
            mode = view ? Mode.SETUP : Mode.VIEW;
            autoCycle = false;
            clearAndInit();
        }).tip(t(view ? "tip.mode.setup" : "tip.mode.view"));
        btn(30, 3, 20, 18, Text.literal("◐"), () -> {
            ModConfig.get().theme = (UiUtil.shiftDown() ? Theme.prev(ModConfig.get().theme) : Theme.next(ModConfig.get().theme)).id();
            ModConfig.save();
            applyFx();
            clearAndInit();
        }).tip(t("theme", Theme.current().label()));
        btn(52, 3, 20, 18, Text.literal("★"), () -> favOnly = !favOnly).toggled(() -> favOnly).tip(t("tip.favonly"));
        btn(width - 28, 3, 20, 18, Text.literal("✕"), this::close).tip(t("tip.close"));
    }

    // ------------------------------------------------------------ ПРОСМОТР

    private void computeViewport() {
        int top = 25, bottom = height - 4;
        int availH = Math.max(40, bottom - top);
        int availW = width - 8;
        vh = (int) (availH * ModConfig.get().viewportScale);
        vw = Math.min(availW, (int) (vh * ((float) width / height)));
        vx = (width - vw) / 2;
        vy = top + (availH - vh) / 2;
    }

    private int stripX() { return vx + vw / 2 - 110; }

    private int stripY() { return vy + vh - 30; }

    private void buildView() {
        computeViewport();
        int x0 = stripX(), y0 = stripY() + 4;
        prevBtn = btn(x0, y0, 20, 20, Text.literal("◀"), () -> step(-1)).tip(t("tip.prev"));
        nextBtn = btn(x0 + 132, y0, 20, 20, Text.literal("▶"), () -> step(1)).tip(t("tip.next"));
        favBtn = btn(x0 + 154, y0, 20, 20, Text.literal("★"), this::toggleFav).tip(t("tip.fav"));
        favBtn.toggled(() -> {
            Entry c = current();
            return c != null && c.meta().favorite;
        });
        autoBtn = btn(x0 + 176, y0, 20, 20, Text.literal("↻"), () -> {
            autoCycle = !autoCycle;
            Sfx.auto(autoCycle);
            lastSwitch = System.currentTimeMillis();
        }).tip(t("tip.auto", ModConfig.get().autoCycleSeconds));
        autoBtn.toggled(() -> autoCycle);
        shotBtn = btn(x0 + 198, y0, 20, 20, Text.literal("◉"), () -> shotPending = true).tip(t("tip.shot"));
    }

    private void refreshButtons() {
        if (prevBtn == null) return;
        Entry c = current();
        boolean multi = entries(favOnly).size() > 1;
        boolean ok = c != null && signal != null && signal.ok();
        prevBtn.active = multi;
        nextBtn.active = multi;
        autoBtn.active = multi;
        favBtn.active = c != null;
        shotBtn.active = ok;
    }

    private float zoomOf(Entry e) {
        float z = e.meta().zoom;
        return z < 1f ? 1f : Math.min(z, 8f);
    }

    private void setZoom(float z) {
        Entry c = current();
        if (c == null) return;
        z = Math.max(1f, Math.min(8f, Math.round(z * 100f) / 100f));
        if (z != c.meta().zoom) {
            c.meta().zoom = z; // сохраняется в данных мира вместе с камерой
            Sfx.zoom();
            Store.markDirty();
        }
    }

    private void toggleFav() {
        Entry c = current();
        if (c == null) return;
        c.meta().favorite = !c.meta().favorite;
        Store.markDirty();
    }

    private void pollKeys() {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        long h = client.getWindow().getHandle();
        float sp = 70f * dt;
        int range = ModConfig.get().lookRange;
        if (GLFW.glfwGetKey(h, GLFW.GLFW_KEY_A) == GLFW.GLFW_PRESS) lookYaw -= sp;
        if (GLFW.glfwGetKey(h, GLFW.GLFW_KEY_D) == GLFW.GLFW_PRESS) lookYaw += sp;
        if (GLFW.glfwGetKey(h, GLFW.GLFW_KEY_W) == GLFW.GLFW_PRESS) lookPitch -= sp;
        if (GLFW.glfwGetKey(h, GLFW.GLFW_KEY_S) == GLFW.GLFW_PRESS) lookPitch += sp;
        lookYaw = Math.max(-range, Math.min(range, lookYaw));
        lookPitch = Math.max(-range / 2f, Math.min(range / 2f, lookPitch));
        boolean ck = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_C) == GLFW.GLFW_PRESS;
        if (ck && !prevC) {
            lookYaw = 0;
            lookPitch = 0;
            status(t("look.reset"));
        }
        prevC = ck;
        saveLook();
        Entry zc = current();
        if (zc != null) {
            float zf = (float) Math.pow(2.2, dt);
            if (GLFW.glfwGetKey(h, GLFW.GLFW_KEY_E) == GLFW.GLFW_PRESS) setZoom(zoomOf(zc) * zf);
            if (GLFW.glfwGetKey(h, GLFW.GLFW_KEY_Q) == GLFW.GLFW_PRESS) setZoom(zoomOf(zc) / zf);
        }
        for (int n = 0; n < 9; n++) {
            boolean down = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_1 + n) == GLFW.GLFW_PRESS;
            if (down && !prevNum[n]) jumpFav(n);
            prevNum[n] = down;
        }
        boolean l = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_RIGHT) == GLFW.GLFW_PRESS;
        if (l && !prevL) step(-1);
        if (r && !prevR) step(1);
        prevL = l;
        prevR = r;
        if (autoCycle && entries(favOnly).size() > 1
                && System.currentTimeMillis() - lastSwitch > ModConfig.get().autoCycleSeconds * 1000L) step(1);
    }

    private void updateCamera() {
        Entry cur = current();
        tooFar = false;
        weak = 0;
        lensRain = 0;
        if (cur == null || client.world == null) {
            signal = null;
            CameraView.INSTANCE.deactivate();
            return;
        }
        Cameras.Live live = Cameras.find(cur.tag(), cur.idx());
        signal = Signal.resolve(live, client.world, lastDelta);

        // Радиус действия: за пределом сигнал слабеет, в 1,5 раза дальше — пропадает.
        int range = ModConfig.get().signalRange;
        if (signal.ok() && range > 0 && client.player != null) {
            double r = signal.pos().distanceTo(client.player.getEyePos()) / range;
            if (r >= 1.5) {
                tooFar = true;
                signal = new Signal(false, Vec3d.ZERO, 0, 0, "");
            } else if (r > 1.0) {
                weak = (float) ((r - 1.0) / 0.5);
            }
        }

        if (!signal.ok()) {
            CameraView.INSTANCE.deactivate();
            applyView(null);
            if (weakLevel != 0) {
                weakLevel = 0;
                applyFx();
            }
            return;
        }

        // Ночное видение: включается, когда в точке камеры темно (с гистерезисом, чтобы не мигать).
        if (ModConfig.get().nightVision && fxApplied) {
            long now = System.currentTimeMillis();
            if (now - lightCheck > 250) {
                lightCheck = now;
                int lvl = client.world.getLightLevel(BlockPos.ofFloored(signal.pos()), client.world.getAmbientDarkness());
                boolean want = night ? lvl <= 6 : lvl <= 3;
                if (want != night) {
                    night = want;
                    applyFx();
                }
            }
        } else if (night) {
            night = false;
            applyFx();
        }

        // Дождь на объективе блочной камеры: идёт дождь, над камерой открытое небо и в биоме бывают осадки.
        if ("BLOCK".equals(signal.src()) && ModConfig.get().lensEffects) {
            BlockPos bp = BlockPos.ofFloored(signal.pos());
            float rg = client.world.getRainGradient(lastDelta);
            if (rg > 0.05f && client.world.isSkyVisible(bp) && client.world.getBiome(bp).value().hasPrecipitation()) lensRain = rg;
        }

        // Слабый сигнал: шейдер искажает картинку ступенями (6 уровней, с гистерезисом),
        // а между ступенями картинка непрерывно дрожит и «дышит» вместе с самой камерой.
        if (fxApplied) {
            double f = weak * 6.0;
            int want = weak <= 0 ? 0 : (int) Math.max(1, Math.min(6, Math.ceil(f)));
            if (want != weakLevel && (want == 0 || weakLevel == 0 || Math.abs(f - weakLevel + 0.5) > 0.65)) {
                weakLevel = want;
                applyFx();
            }
        }
        float jy = 0, jp = 0, zoomMul = 1f;
        if (weak > 0) {
            double tt = System.currentTimeMillis() / 1000.0;
            jy = (float) ((Math.sin(tt * 7.3) * 0.6 + Math.sin(tt * 13.1 + 1.7) * 0.4) * weak * 1.4);
            jp = (float) ((Math.sin(tt * 5.1 + 0.5) * 0.6 + Math.sin(tt * 11.7) * 0.4) * weak * 0.9);
            if ((tt * 0.37) % 1.0 < 0.05 * weak) jy += 3.5f * weak; // редкий «срыв» синхронизации
            zoomMul = 1f + weak * 0.05f * (1f + (float) Math.sin(tt * 3.1)); // лёгкое «дыхание» кадра
        }
        float zoom = Math.min(8f, zoomOf(cur) * zoomMul);

        boolean head = "HEAD".equals(signal.src());
        boolean hand = "HAND".equals(signal.src());
        applyView((head || hand) && live != null ? client.world.getEntityById(live.entityId()) : null);
        if (head) {
            CameraView.INSTANCE.setOffset(lookYaw + jy, lookPitch + jp, zoom);
        } else {
            float pitch = Math.max(-89f, Math.min(89f, signal.pitch() + lookPitch + jp));
            CameraView.INSTANCE.setAbsolute(signal.pos(), signal.yaw() + lookYaw + jy, pitch, zoom);
        }
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        if (mode == Mode.SETUP) {
            listScroll = Math.max(0, listScroll + (v > 0 ? -1 : 1));
            setupSig = "";
            return true;
        }
        Entry c = current();
        if (c != null) setZoom(zoomOf(c) * (v > 0 ? 1.15f : 1f / 1.15f));
        return true;
    }

    private void ctext(DrawContext g, String s, int cx, int y, int color, boolean shadow) {
        g.drawText(textRenderer, s, cx - textRenderer.getWidth(s) / 2, y, color, shadow);
    }

    private String nameOf(Entry e) { return e.label(); }

    private FeedEffects.Info info(Entry cur) {
        var p = signal.pos();
        return new FeedEffects.Info(nameOf(cur), p.x, p.y, p.z, signal.yaw() + lookYaw, signal.pitch() + lookPitch, signal.src());
    }

    /** clean = без интерфейса (скриншот, запись): эффекты на весь экран. */
    private void drawView(DrawContext g, Theme t, boolean clean) {
        Entry cur = current();
        boolean ok = cur != null && signal != null && signal.ok();
        int rx = clean ? 0 : vx, ry = clean ? 0 : vy, rw = clean ? width : vw, rh = clean ? height : vh;
        if (!clean) {
            g.fill(0, 0, width, vy, t.bg());
            g.fill(0, vy + vh, width, height, t.bg());
            g.fill(0, vy, vx, vy + vh, t.bg());
            g.fill(vx + vw, vy, width, vy + vh, t.bg());
        }
        if (!ok) {
            String sub = cur == null ? t("view.empty").getString() : t(tooFar ? "signal.far" : "signal.offline").getString();
            FeedEffects.noSignal(g, textRenderer, t, rx, ry, rw, rh, t("signal.none").getString(), sub);
        } else {
            FeedEffects.draw(g, textRenderer, t, rx, ry, rw, rh, info(cur), fxApplied);
            if ("BLOCK".equals(signal.src()) && ModConfig.get().lensEffects)
                LensEffects.draw(g, rx, ry, rw, rh, lensRain, ModConfig.get().lensDust / 100f, cur.key(), System.currentTimeMillis());
            if (weak > 0) FeedEffects.interference(g, textRenderer, t, rx, ry, rw, rh, weak, System.currentTimeMillis());
            if (night) {
                String nv = "◐ NIGHT VISION";
                g.drawText(textRenderer, nv, rx + rw - 8 - textRenderer.getWidth(nv), ry + 36, 0xFF7CFF8C, true);
            }
            if (!clean && ModConfig.get().showCoords && !t.id().equals("tactical") && !t.id().equals("cyber")) {
                var p = signal.pos();
                String c = (int) p.x + " " + (int) p.y + " " + (int) p.z;
                g.drawText(textRenderer, c, rx + rw - 8 - textRenderer.getWidth(c), ry + 24, 0xFFFFFFFF, true);
            }
            if (Cameras.hasMotion(cur.tag(), cur.idx()) && (System.currentTimeMillis() / 300) % 2 == 0) {
                String m = "⚠ " + t("motion.label").getString();
                g.fill(rx + rw / 2 - textRenderer.getWidth(m) / 2 - 6, ry + 8, rx + rw / 2 + textRenderer.getWidth(m) / 2 + 6, ry + 22, 0xB0000000);
                ctext(g, m, rx + rw / 2, ry + 11, t.bad(), false);
            }
        }
        if (clean) return;
        FeedEffects.frame(g, t, vx, vy, vw, vh);

        // Название монитора и компактная панель управления поверх нижнего края изображения.
        String ml = textRenderer.trimToWidth(monitorLabel(), Math.max(20, width - 140));
        if (t.id().equals("terminal")) UiUtil.mono(g, textRenderer, ml.toUpperCase() + ((System.currentTimeMillis() / 500) % 2 == 0 ? "_" : " "), 78, 9, t.dim(), false);
        else g.drawText(textRenderer, ml, 78, 9, t.dim(), false);
        int x0 = stripX(), y0 = stripY();
        UiUtil.rounded(g, x0 - 4, y0, 226, 28, t.panel(), t.border());
        if (cur != null) {
            int fn = cur.meta().favorite ? favNo(cur) : 0;
            String nm = textRenderer.trimToWidth((cur.meta().favorite ? "★" + (fn >= 1 && fn <= 9 ? fn : "") + " " : "") + nameOf(cur), 106);
            ctext(g, nm, x0 + 77, y0 + 5, t.text(), false);
            List<Entry> l = entries(favOnly);
            String zoom = zoomOf(cur) > 1.01f ? "  ×" + String.format(Locale.ROOT, "%.1f", zoomOf(cur)) : "";
            ctext(g, textRenderer.trimToWidth((positionOf(l, cur.key()) + 1) + "/" + l.size() + zoom, 106), x0 + 77, y0 + 16, t.dim(), false);
        } else {
            ctext(g, t("view.empty").getString(), x0 + 77, y0 + 10, t.dim(), false);
        }
        g.drawText(textRenderer, textRenderer.trimToWidth(t("view.hint").getString(), Math.max(0, vw / 2 - 134)),
                vx + 8, vy + vh - 14, 0xB0FFFFFF, true);
    }

    private String fileSafe(String s) { return s.replaceAll("[^\\p{L}\\p{N}_-]", "_"); }

    private void takeShot(Entry cur) {
        Sfx.shutter();
        String file = "cam_" + fileSafe(cur.label()) + "_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".png";
        ScreenshotRecorder.saveScreenshot(client.runDirectory, file, client.getFramebuffer(), 1,
                msg -> client.execute(() -> client.inGameHud.getChatHud().addMessage(msg)));
    }

    // ------------------------------------------------------------ НАСТРОЙКА (список найденных камер)

    private int cellX(int slot) { return gridX + (slot < 9 ? slot : (slot - 9) % 9) * CELL; }

    private int cellY(int slot) {
        int row = slot < 9 ? 3 : (slot - 9) / 9;
        return gridY + row * CELL + (row == 3 ? 6 : 0);
    }

    private String signature() {
        StringBuilder sb = new StringBuilder();
        for (Entry e : entries(false)) sb.append(e.key()).append(e.meta().favorite ? '*' : '.').append(',');
        return sb.append(listScroll).toString();
    }

    private void buildSetup() {
        setupSig = signature();
        panelX = 8;
        panelY = 26;
        panelW = width - 16;
        panelH = height - 30;
        leftW = Math.min(Math.max(250, (int) (panelW * 0.58)), panelW - 196);
        rightX = panelX + leftW + 8;
        int rightW = panelW - leftW - 8;

        int[] c = {panelX + 5, panelY + 5};
        int maxX = panelX + leftW - 4;
        autoBtn(c, maxX, 16, t("setup.refresh"), () -> { Cameras.refresh(); clearAndInit(); }).tip(t("setup.refresh.tip"));
        autoBtn(c, maxX, 16, t("name.camera"), () -> copyName(Heads.cameraName(helperTag(), nextIndex(helperTag())))).tip(t("name.camera.tip"));
        autoBtn(c, maxX, 16, t("name.monitor"), () -> copyName(Heads.monitorName(
                monitorTags.isEmpty() ? (helperTag().isEmpty() ? List.<String>of() : List.of(helperTag())) : monitorTags))).tip(t("name.monitor.tip"));

        int listTop = c[1] + 22;
        int rowH = 20;
        List<Entry> cams = entries(false);
        int visible = Math.max(1, (panelY + panelH - 18 - listTop) / rowH);
        listScroll = Math.max(0, Math.min(listScroll, Math.max(0, cams.size() - visible)));
        int bx = panelX + leftW - 6 - 3 * 20 + 2;
        for (int r = 0; r < visible && listScroll + r < cams.size(); r++) {
            Entry e = cams.get(listScroll + r);
            int ry = listTop + r * rowH;
            rowEntries.add(e);
            rowYs.add(ry);
            btn(bx, ry + 1, 18, 18, Text.literal("★"), () -> { e.meta().favorite = !e.meta().favorite; Store.markDirty(); })
                    .toggled(() -> e.meta().favorite).tip(t("tip.fav"));
            btn(bx + 20, ry + 1, 18, 18, Text.literal("⎘"), () -> copyName(Heads.cameraName(e.tag(), e.idx()))).tip(t("tip.copyname"));
            btn(bx + 40, ry + 1, 18, 18, Text.literal("▶"), () -> {
                curKey = e.key();
                favOnly = false;
                resetLook();
                mode = Mode.VIEW;
                remember();
                clearAndInit();
            }).tip(t("tip.watch"));
        }

        // превью инвентаря: только головы Camera
        gridX = rightX + Math.max(0, (rightW - 9 * CELL) / 2);
        gridY = panelY + 30;
        nameCounter = nextIndex(helperTag());
        var player = client.player;
        String ht = helperTag();
        for (int s = 0; s < 36; s++) {
            final int slot = s;
            ItemStack st = player == null ? ItemStack.EMPTY : player.getInventory().getStack(slot);
            Heads.Parsed p = Heads.parse(st);
            camSlot[slot] = p.kind() == Heads.Kind.CAMERA;
            if (!camSlot[slot]) continue;
            Supplier<ItemStack> sup = () -> client.player == null ? ItemStack.EMPTY : client.player.getInventory().getStack(slot);
            boolean match = p.tag().equals(ht);
            SlotButton sb = new SlotButton(cellX(slot), cellY(slot), sup, () -> match ? 1 : 0, b -> copyName(Heads.cameraName(ht, nameCounter++)));
            sb.setTooltip(Tooltip.of(Text.literal(st.getName().getString() + " → " + t("slot.tip").getString())));
            addDrawableChild(sb);
        }
    }

    private void drawSetup(DrawContext g, Theme t) {
        g.fill(0, 0, width, height, t.bg());
        UiUtil.rounded(g, panelX, panelY, leftW, panelH, t.panel(), t.border());
        UiUtil.rounded(g, rightX, panelY, panelW - leftW - 8, panelH, t.panel(), t.border());

        int nameMax = leftW - 3 * 20 - 90;
        for (int i = 0; i < rowEntries.size(); i++) {
            Entry e = rowEntries.get(i);
            int ry = rowYs.get(i);
            UiUtil.rounded(g, panelX + 4, ry, leftW - 8, 20, t.panelAlt(), t.border());
            Cameras.Live live = Cameras.find(e.tag(), e.idx());
            int dot = Cameras.hasMotion(e.tag(), e.idx()) ? 0xFFE0A030 : live != null ? t.good() : t.bad();
            g.fill(panelX + 10, ry + 7, panelX + 16, ry + 13, dot);
            g.drawText(textRenderer, textRenderer.trimToWidth(e.label(), nameMax), panelX + 22, ry + 6, t.text(), false);
            if (live != null) {
                String src = live.src().name();
                g.drawText(textRenderer, src, panelX + leftW - 6 - 3 * 20 - 6 - textRenderer.getWidth(src), ry + 6, t.dim(), false);
            }
        }
        if (rowEntries.isEmpty())
            g.drawText(textRenderer, t("setup.empty_list").getString(), panelX + 12, panelY + panelH / 2, t.dim(), false);
        g.drawText(textRenderer, t("setup.legend").getString(), panelX + 8, panelY + panelH - 14, t.dim(), false);

        int total = 0;
        for (int s = 0; s < 36; s++) {
            ItemStack st = client.player == null ? ItemStack.EMPTY : client.player.getInventory().getStack(s);
            if (camSlot[s]) total += st.getCount();
        }
        g.drawText(textRenderer, t("setup.inv.title", total).getString(), gridX, panelY + 6, t.text(), false);
        g.drawText(textRenderer, t("setup.inv.hint").getString(), gridX, panelY + 17, t.dim(), false);
        for (int s = 0; s < 36; s++) {
            if (camSlot[s]) continue;
            UiUtil.rounded(g, cellX(s), cellY(s), CELL, CELL, UiUtil.mix(t.panel(), t.panelAlt(), 0.5f), UiUtil.mix(t.panel(), t.border(), 0.6f));
        }
        int below = gridY + 4 * CELL + 12;
        g.drawText(textRenderer, t("setup.next", Heads.cameraName(helperTag(), nameCounter)).getString(), gridX, below, t.accent(), false);
        if (total == 0) g.drawText(textRenderer, t("setup.inv.none").getString(), gridX, below + 14, t.dim(), false);
    }

    // ------------------------------------------------------------ отрисовка

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        Theme t = Theme.current();
        lastDelta = delta;
        boolean wantStatic = false;
        if (mode == Mode.VIEW) {
            pollKeys();
            updateCamera();
            boolean ok = current() != null && signal != null && signal.ok();
            boolean shot = shotPending && ok;
            shotPending = false;
            wantStatic = current() != null && (!ok || weak > 0.5f);
            drawView(g, t, shot);
            Sfx.noSignal(wantStatic);
            if (shot) {
                takeShot(current());
                return; // этот кадр — только изображение, без кнопок
            }
            refreshButtons();
        } else {
            if (!signature().equals(setupSig)) clearAndInit();
            drawSetup(g, t);
            Sfx.noSignal(false);
        }
        super.render(g, mx, my, delta);
        if (System.currentTimeMillis() < statusUntil) {
            String s = status.getString();
            int w = textRenderer.getWidth(s) + 16;
            int x = (width - w) / 2, y = height - 24;
            UiUtil.rounded(g, x, y, w, 16, t.panelAlt(), t.accent());
            g.drawText(textRenderer, s, x + 8, y + 4, t.text(), false);
        }
    }

    // ------------------------------------------------------------ слот

    private static final class SlotButton extends ButtonWidget {
        private final Supplier<ItemStack> stack;
        private final IntSupplier match;

        SlotButton(int x, int y, Supplier<ItemStack> stack, IntSupplier match, PressAction action) {
            super(x, y, CELL, CELL, net.minecraft.text.Text.empty(), action, DEFAULT_NARRATION_SUPPLIER);
            this.stack = stack;
            this.match = match;
        }

        @Override
        protected void drawIcon(DrawContext g, int mx, int my, float delta) {
            Theme t = Theme.current();
            boolean m = match.getAsInt() > 0;
            UiUtil.rounded(g, getX(), getY(), getWidth(), getHeight(),
                    m ? UiUtil.mix(t.panelAlt(), t.accent(), 0.4f) : t.panelAlt(),
                    m || isHovered() ? t.accent() : t.border());
            ItemStack s = stack.get();
            TextRenderer tr = MinecraftClient.getInstance().textRenderer;
            g.drawItem(s, getX() + 2, getY() + 2);
            g.drawStackOverlay(tr, s, getX() + 2, getY() + 2);
        }
    }
}
