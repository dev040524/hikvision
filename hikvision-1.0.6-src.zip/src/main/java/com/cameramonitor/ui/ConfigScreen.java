package com.cameramonitor.ui;

import com.cameramonitor.ModConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Настройки с категориями: слева список разделов, справа параметры выбранного раздела. */
public class ConfigScreen extends Screen {
    private enum Cat { DISPLAY, VIEWING, CAMERAS, MOTION }

    /** Строка настройки: либо кнопка-переключатель, либо текстовое поле (если text != null). */
    private record Row(String key, Supplier<Text> value, Runnable click, Runnable reset,
                       Supplier<String> text, Consumer<String> setText) {}

    private static Cat selected = Cat.DISPLAY;
    private final Screen parent;
    private final List<Row> rows = new ArrayList<>();
    private int contentX;
    private int rowScroll;

    public ConfigScreen(Screen parent) {
        super(Text.translatable("cameramonitor.config.title"));
        this.parent = parent;
    }

    private static Text onOff(boolean b) {
        return Text.translatable(b ? "cameramonitor.config.on" : "cameramonitor.config.off");
    }

    private static double cycle(double cur, double[] vals) {
        for (int i = 0; i < vals.length; i++) if (Math.abs(vals[i] - cur) < 0.001) return vals[(i + 1) % vals.length];
        return vals[0];
    }

    private static Row opt(String key, Supplier<Text> value, Runnable click, Runnable reset) {
        return new Row(key, value, click, reset, null, null);
    }

    private static Row txt(String key, Supplier<String> get, Consumer<String> set, Runnable reset) {
        return new Row(key, null, null, reset, get, set);
    }

    private List<Row> rowsOf(Cat cat) {
        ModConfig c = ModConfig.get();
        ModConfig d = new ModConfig(); // значения по умолчанию
        return switch (cat) {
            case DISPLAY -> List.of(
                    opt("theme", () -> Theme.byId(c.theme).label(), () -> c.theme = (UiUtil.shiftDown() ? Theme.prev(c.theme) : Theme.next(c.theme)).id(), () -> c.theme = d.theme),
                    opt("backgroundOpacity", () -> Text.literal(Math.round(c.backgroundOpacity * 100) + "%"),
                            () -> c.backgroundOpacity = cycle(c.backgroundOpacity, new double[]{0.0, 0.25, 0.5, 0.75, 0.9, 1.0}),
                            () -> c.backgroundOpacity = d.backgroundOpacity),
                    opt("viewportScale", () -> Text.literal(Math.round(c.viewportScale * 100) + "%"),
                            () -> c.viewportScale = cycle(c.viewportScale, new double[]{0.6, 0.7, 0.8, 0.9, 1.0}),
                            () -> c.viewportScale = d.viewportScale),
                    opt("useShader", () -> onOff(c.useShader), () -> c.useShader = !c.useShader, () -> c.useShader = d.useShader),
                    opt("lensEffects", () -> onOff(c.lensEffects), () -> c.lensEffects = !c.lensEffects, () -> c.lensEffects = d.lensEffects),
                    opt("lensDust", () -> Text.literal(c.lensDust + "%"),
                            () -> c.lensDust = (int) cycle(c.lensDust, new double[]{0, 15, 30, 60, 100}), () -> c.lensDust = d.lensDust),
                    opt("scanlines", () -> onOff(c.scanlines), () -> c.scanlines = !c.scanlines, () -> c.scanlines = d.scanlines),
                    opt("showCoords", () -> onOff(c.showCoords), () -> c.showCoords = !c.showCoords, () -> c.showCoords = d.showCoords));
            case VIEWING -> List.of(
                    opt("sounds", () -> onOff(c.sounds), () -> c.sounds = !c.sounds, () -> c.sounds = d.sounds),
                    opt("nightVision", () -> onOff(c.nightVision), () -> c.nightVision = !c.nightVision, () -> c.nightVision = d.nightVision),
                    opt("rememberLook", () -> onOff(c.rememberLook), () -> c.rememberLook = !c.rememberLook, () -> c.rememberLook = d.rememberLook),
                    opt("openLastCamera", () -> onOff(c.openLastCamera), () -> c.openLastCamera = !c.openLastCamera, () -> c.openLastCamera = d.openLastCamera),
                    opt("autoCycleSeconds", () -> Text.literal(c.autoCycleSeconds + " s"),
                            () -> c.autoCycleSeconds = (int) cycle(c.autoCycleSeconds, new double[]{3, 5, 10, 20, 30}),
                            () -> c.autoCycleSeconds = d.autoCycleSeconds),
                    opt("lookRange", () -> Text.literal(c.lookRange + "°"),
                            () -> c.lookRange = (int) cycle(c.lookRange, new double[]{0, 30, 45, 60, 90}),
                            () -> c.lookRange = d.lookRange));
            case CAMERAS -> List.of(
                    opt("placeRequiresSneak", () -> onOff(c.placeRequiresSneak), () -> c.placeRequiresSneak = !c.placeRequiresSneak, () -> c.placeRequiresSneak = d.placeRequiresSneak),
                    opt("signalRange", () -> c.signalRange == 0 ? Text.translatable("cameramonitor.config.off") : Text.literal(c.signalRange + " m"),
                            () -> c.signalRange = (int) cycle(c.signalRange, new double[]{0, 32, 64, 128, 256}), () -> c.signalRange = d.signalRange),
                    opt("handSway", () -> Text.literal(c.handSway + "%"),
                            () -> c.handSway = (int) cycle(c.handSway, new double[]{0, 50, 100, 150, 200}), () -> c.handSway = d.handSway),
                    opt("carriedCameras", () -> onOff(c.carriedCameras), () -> c.carriedCameras = !c.carriedCameras, () -> c.carriedCameras = d.carriedCameras),
                    txt("cameraPrefix", () -> c.cameraPrefix, v -> c.cameraPrefix = v, () -> c.cameraPrefix = d.cameraPrefix),
                    txt("monitorPrefix", () -> c.monitorPrefix, v -> c.monitorPrefix = v, () -> c.monitorPrefix = d.monitorPrefix));
            case MOTION -> List.of(
                    opt("motionAlerts", () -> onOff(c.motionAlerts), () -> c.motionAlerts = !c.motionAlerts, () -> c.motionAlerts = d.motionAlerts),
                    opt("motionRadius", () -> Text.literal(c.motionRadius + " m"),
                            () -> c.motionRadius = (int) cycle(c.motionRadius, new double[]{4, 8, 12, 16, 24}),
                            () -> c.motionRadius = d.motionRadius),
                    opt("motionMobs", () -> onOff(c.motionMobs), () -> c.motionMobs = !c.motionMobs, () -> c.motionMobs = d.motionMobs));
        };
    }

    @Override
    protected void init() {
        rows.clear();
        int sideW = 118;
        int y = 36;
        for (Cat cat : Cat.values()) {
            ButtonWidget b = ButtonWidget.builder(Text.translatable("cameramonitor.config.cat." + cat.name().toLowerCase()), bb -> {
                selected = cat;
                rowScroll = 0;
                clearAndInit();
            }).dimensions(10, y, sideW, 20).build();
            b.active = cat != selected; // выбранная категория подсвечена как нажатая
            addDrawableChild(b);
            y += 24;
        }

        contentX = 10 + sideW + 20;
        int valueW = 130;
        int valueX = Math.min(width - valueW - 12, contentX + 190);
        int ry = 36;
        List<Row> all = rowsOf(selected);
        int visible = Math.max(3, (height - 36 - 44) / 26);
        rowScroll = Math.max(0, Math.min(rowScroll, Math.max(0, all.size() - visible)));
        rows.addAll(all.subList(rowScroll, Math.min(all.size(), rowScroll + visible)));
        for (Row r : rows) {
            Tooltip tip = Tooltip.of(Text.translatable("cameramonitor.config." + r.key() + ".desc"));
            if (r.text() == null) {
                addDrawableChild(ButtonWidget.builder(r.value().get(), b -> {
                    r.click().run();
                    ModConfig.save();
                    clearAndInit();
                }).dimensions(valueX, ry, valueW, 20).tooltip(tip).build());
            } else {
                TextFieldWidget f = new TextFieldWidget(textRenderer, valueX, ry, valueW, 20, Text.empty());
                f.setMaxLength(24);
                f.setText(r.text().get());
                f.setChangedListener(v -> {
                    if (!v.isBlank()) {
                        r.setText().accept(v.trim());
                        ModConfig.save();
                    }
                });
                f.setTooltip(tip);
                addDrawableChild(f);
            }
            ry += 26;
        }

        addDrawableChild(ButtonWidget.builder(Text.translatable("cameramonitor.config.reset"), b -> {
            for (Row r : rowsOf(selected)) r.reset().run(); // сбрасываем весь раздел, а не только видимые строки
            ModConfig.save();
            clearAndInit();
        }).dimensions(contentX, height - 30, 130, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("cameramonitor.config.done"), b -> close())
                .dimensions(width - 142, height - 30, 130, 20).build());
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        g.drawText(textRenderer, title, 10, 14, 0xFFFFFFFF, true);
        g.fill(10 + 118 + 9, 34, 10 + 118 + 10, height - 38, 0x40FFFFFF);
        int ry = 36;
        for (Row r : rows) {
            g.drawText(textRenderer, Text.translatable("cameramonitor.config." + r.key()), contentX, ry + 6, 0xFFE6E6E6, true);
            ry += 26;
        }
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        rowScroll = Math.max(0, rowScroll + (v > 0 ? -1 : 1));
        clearAndInit();
        return true;
    }

    @Override
    public void close() {
        ModConfig.save();
        client.setScreen(parent);
    }
}
