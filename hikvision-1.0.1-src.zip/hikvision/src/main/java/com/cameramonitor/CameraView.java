package com.cameramonitor;

import net.minecraft.util.math.Vec3d;

/**
 * Состояние «виртуальной камеры», которое применяет CameraMixin.
 * ABSOLUTE — позиция и углы задаются полностью (блок, рука).
 * OFFSET — позиция и базовый взгляд берутся у игры (камера на голове: игра сама ведёт камеру сущности),
 * мы добавляем только небольшой осмотр на WASD.
 */
public final class CameraView {
    public static final CameraView INSTANCE = new CameraView();

    private boolean active, absolute;
    private double x, y, z;
    private float yaw, pitch, zoom = 1f;

    public void setAbsolute(Vec3d p, float yaw, float pitch, float zoom) {
        this.x = p.x;
        this.y = p.y;
        this.z = p.z;
        this.yaw = yaw;
        this.pitch = pitch;
        this.zoom = zoom;
        this.absolute = true;
        this.active = true;
    }

    public void setOffset(float yawOffset, float pitchOffset, float zoom) {
        this.yaw = yawOffset;
        this.pitch = pitchOffset;
        this.zoom = zoom;
        this.absolute = false;
        this.active = true;
    }

    public void deactivate() { active = false; }
    public boolean isActive() { return active; }
    public boolean absolute() { return absolute; }
    public double x() { return x; }
    public double y() { return y; }
    public double z() { return z; }
    public float yaw() { return yaw; }
    public float pitch() { return pitch; }
    public float zoom() { return zoom; }
}
