package com.cameramonitor;

import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Arm;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

/**
 * Положение и направление живой камеры: блок, голова существа или его рука.
 * src: «BLOCK», «HEAD» (вид глазами; камеру ведёт игра), «HAND» (вид из руки, считается по формуле ванильной анимации).
 */
public record Signal(boolean ok, Vec3d pos, float yaw, float pitch, String src) {
    private static final Signal OFFLINE = new Signal(false, Vec3d.ZERO, 0, 0, "");

    public static Signal resolve(Cameras.Live l, World w, float delta) {
        if (l == null) return OFFLINE;
        return l.src() == Cameras.Src.BLOCK ? fromBlock(l.pos(), w) : fromEntity(l, w, delta);
    }

    private static Signal fromBlock(BlockPos p, World w) {
        BlockState st = w.getBlockState(p);
        if (!(st.getBlock() instanceof AbstractSkullBlock)) return OFFLINE;
        float yaw = 0;
        boolean wall = false;
        if (st.contains(Properties.ROTATION)) {
            // Лицевая сторона напольной головы смотрит противоположно ROTATION*22.5° — поэтому +180.
            yaw = st.get(Properties.ROTATION) * 22.5f + 180f;
        } else if (st.contains(Properties.HORIZONTAL_FACING)) {
            wall = true;
            Direction d = st.get(Properties.HORIZONTAL_FACING);
            yaw = switch (d) {
                case WEST -> 90f;
                case NORTH -> 180f;
                case EAST -> 270f;
                default -> 0f;
            };
        }
        double r = Math.toRadians(yaw);
        Vec3d fwd = new Vec3d(-Math.sin(r), 0, Math.cos(r));
        Vec3d base = new Vec3d(p.getX() + 0.5, p.getY() + (wall ? 0.5 : 0.32), p.getZ() + 0.5);
        return new Signal(true, base.add(fwd.multiply(0.32)), yaw, 0f, "BLOCK");
    }

    private static Signal fromEntity(Cameras.Live l, World w, float delta) {
        Entity e = w.getEntityById(l.entityId());
        if (!(e instanceof LivingEntity le)) return OFFLINE;
        Cameras.Src s = Cameras.srcOf(le, l.tag(), l.index());
        if (s == null) return OFFLINE; // камеру сняли или убрали из рук

        Vec3d eye = le.getCameraPosVec(delta);
        float yaw = le instanceof PlayerEntity ? le.getYaw(delta) : le.getHeadYaw();
        float pitch = le.getPitch(delta);
        if (s == Cameras.Src.HEAD) {
            // Реальную камеру ведёт игра (камера-сущность, первое лицо): точное положение глаз и взгляд,
            // модель носителя при этом не рисуется. Здесь только данные для расстояния и подписей.
            return new Signal(true, eye, yaw, pitch, "HEAD");
        }
        return hand(le, s, w, eye, yaw, pitch, delta);
    }

    /**
     * Камера в руке. Положение считается из тех же величин, что двигают руку в ванильной модели
     * (фаза шага, скорость, «дыхание», приседание, угол тела), поэтому оно не зависит от ресурспака и текстур.
     */
    private static Signal hand(LivingEntity le, Cameras.Src s, World w, Vec3d eye, float yaw, float pitch, float delta) {
        double sway = ModConfig.get().handSway / 100.0;
        boolean right = (s == Cameras.Src.MAIN) == (le.getMainArm() == Arm.RIGHT);
        double side = right ? 1.0 : -1.0;

        double br = Math.toRadians(Cameras.bodyYaw(le, delta));
        Vec3d bodyFwd = new Vec3d(-Math.sin(br), 0, Math.cos(br));
        Vec3d bodyRight = new Vec3d(-Math.cos(br), 0, -Math.sin(br));

        float limbPos = le.limbAnimator.getAnimationProgress(delta);
        float limbSpeed = Math.min(1f, le.limbAnimator.getSpeed());
        double phase = limbPos * 0.6662;
        // BipedEntityModel: правая рука cos(phase+π)·speed, левая cos(phase)·speed; плюс «дыхание» sin(age·0.067)·0.05.
        double age = le.age + delta;
        double armPitch = ((right ? -Math.cos(phase) : Math.cos(phase)) * limbSpeed + side * Math.sin(age * 0.067) * 0.05) * sway;

        // Плечо: на 0,25 ниже глаз, на 5/16 в сторону от оси тела (при приседании тело наклонено вперёд).
        Vec3d shoulder = eye.add(0, -0.25, 0).add(bodyRight.multiply(side * 0.3125));
        if (le.isSneaking()) shoulder = shoulder.add(bodyFwd.multiply(0.18));
        double armLen = 0.70;
        Vec3d handPos = shoulder.add(bodyFwd.multiply(-Math.sin(armPitch) * armLen)).add(0, -Math.cos(armPitch) * armLen, 0);

        // Объектив выносим вперёд по взгляду, чтобы не упираться в предмет и руку.
        double gy = Math.toRadians(yaw);
        Vec3d gazeFwd = new Vec3d(-Math.sin(gy), 0, Math.cos(gy));
        Vec3d cam = handPos.add(gazeFwd.multiply(0.30)).add(0, 0.08, 0);

        // Не пропускаем камеру сквозь блоки.
        BlockHitResult hit = w.raycast(new RaycastContext(eye, cam, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, le));
        if (hit.getType() == HitResult.Type.BLOCK) {
            Vec3d dir = cam.subtract(eye);
            if (dir.lengthSquared() > 1e-6) cam = hit.getPos().subtract(dir.normalize().multiply(0.08));
        }
        float tilt = (float) Math.toDegrees(armPitch) * 0.4f;
        float roll = (float) (side * Math.sin(age * 0.09) * 0.5 * sway);
        return new Signal(true, cam, yaw + roll, pitch + tilt, "HAND");
    }
}
