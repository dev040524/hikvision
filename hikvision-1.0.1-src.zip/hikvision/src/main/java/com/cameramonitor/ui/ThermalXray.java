package com.cameramonitor.ui;

import com.cameramonitor.CameraView;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.EntityTypeTags;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Locale;

/**
 * «Просветка» для темы Thermal Vision: живые существа светятся тепловыми силуэтами сквозь стены.
 * Рисуется поверх картинки: положение берётся из настоящей камеры кадра (в том числе камеры сущности),
 * поэтому силуэты совпадают с миром. Существа не загораживаются блоками — это и есть просветка.
 */
public final class ThermalXray {
    private ThermalXray() {}

    private static int heat(float v) {
        float[][] c = {{5, 0, 31}, {89, 0, 140}, {217, 26, 51}, {255, 140, 0}, {255, 242, 77}, {255, 255, 255}};
        float s = Math.max(0f, Math.min(1f, v)) * 5f;
        int k = Math.min(4, (int) s);
        float f = s - k;
        int r = (int) (c[k][0] + (c[k + 1][0] - c[k][0]) * f);
        int g = (int) (c[k][1] + (c[k + 1][1] - c[k][1]) * f);
        int b = (int) (c[k][2] + (c[k + 1][2] - c[k][2]) * f);
        return r << 16 | g << 8 | b;
    }

    public static void draw(DrawContext g, TextRenderer tr, MinecraftClient mc, int sw, int sh,
                            int vx, int vy, int vw, int vh, double range, float delta) {
        if (mc.world == null) return;
        Camera cam = mc.gameRenderer.getCamera();
        Vec3d cp = cam.getCameraPos();
        double yaw = Math.toRadians(cam.getYaw()), pitch = Math.toRadians(cam.getPitch());
        Vec3d fwd = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3d right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3d up = right.crossProduct(fwd);

        double zoom = CameraView.INSTANCE.isActive() ? Math.max(1.0, CameraView.INSTANCE.zoom()) : 1.0;
        double tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0) / zoom;
        double aspect = (double) sw / sh;
        Entity self = mc.getCameraEntity();
        long now = System.currentTimeMillis();

        g.enableScissor(vx, vy, vx + vw, vy + vh);
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || !le.isAlive() || e == self || e instanceof ArmorStandEntity) continue;
            if (cp.squaredDistanceTo(e.getEntityPos()) > range * range) continue;

            Vec3d off = e.getLerpedPos(delta).subtract(e.getEntityPos());
            Box b = e.getBoundingBox().offset(off);
            double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
            int inFront = 0;
            for (int i = 0; i < 8; i++) {
                Vec3d p = new Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ).subtract(cp);
                double z = p.dotProduct(fwd);
                if (z < 0.1) continue;
                inFront++;
                double nx = (p.dotProduct(right) / z) / (tanHalf * aspect);
                double ny = (p.dotProduct(up) / z) / tanHalf;
                double sx = (nx * 0.5 + 0.5) * sw, sy = (0.5 - ny * 0.5) * sh;
                minX = Math.min(minX, sx); maxX = Math.max(maxX, sx);
                minY = Math.min(minY, sy); maxY = Math.max(maxY, sy);
            }
            if (inFront < 8 || maxX < vx || minX > vx + vw || maxY < vy || minY > vy + vh) continue;

            boolean cold = le.getType().isIn(EntityTypeTags.UNDEAD);
            boolean human = le instanceof PlayerEntity;
            double temp = cold ? 14 + 2 * Math.sin(now / 1500.0 + e.getId())
                    : (human ? 36.6 : 38.0) + 0.4 * Math.sin(now / 700.0 + e.getId());
            float base = cold ? 0.22f : (human ? 0.88f : 0.74f);

            int x1 = (int) minX, x2 = (int) maxX, y1 = (int) minY, y2 = (int) maxY;
            int h = Math.max(2, y2 - y1), w = Math.max(2, x2 - x1);
            int step = h > 160 ? 3 : h > 70 ? 2 : 1;
            // Тепловое «пятно»: овал, ядро горячее, края остывают.
            for (int row = 0; row < h; row += step) {
                double t = (row - h / 2.0) / (h / 2.0);
                double half = (w / 2.0) * Math.sqrt(Math.max(0, 1 - t * t));
                if (half < 1) continue;
                float heatV = (float) (base * (0.55 + 0.45 * (1 - Math.abs(t))) + (row < h * 0.22 ? 0.12 : 0));
                int cx = (x1 + x2) / 2;
                g.fill(cx - (int) half, y1 + row, cx + (int) half, y1 + row + step, 0xA0000000 | heat(heatV));
            }
            // Мягкое свечение вокруг.
            UiUtil.outline(g, x1 - 2, y1 - 2, w + 4, h + 4, 0x30000000 | heat(base * 0.8f));

            String label = String.format(Locale.ROOT, "%.1f°C", temp);
            if (human) label += "  " + le.getName().getString() + "  " + (int) Math.sqrt(cp.squaredDistanceTo(e.getEntityPos())) + "m";
            g.drawText(tr, label, (x1 + x2) / 2 - tr.getWidth(label) / 2, y1 - 11, 0xFFFFFFFF, true);
        }
        g.disableScissor();
    }
}
