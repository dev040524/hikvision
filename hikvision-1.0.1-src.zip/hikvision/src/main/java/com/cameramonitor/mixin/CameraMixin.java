package com.cameramonitor.mixin;

import com.cameramonitor.CameraView;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow
    protected abstract void setPos(double x, double y, double z);

    @Shadow
    protected abstract void setRotation(float yaw, float pitch);

    @Shadow
    public abstract float getYaw();

    @Shadow
    public abstract float getPitch();

    @Inject(method = "update", at = @At("RETURN"))
    private void cameramonitor$override(CallbackInfo ci) {
        CameraView v = CameraView.INSTANCE;
        if (!v.isActive()) return;
        if (v.absolute()) {
            setPos(v.x(), v.y(), v.z());
            setRotation(v.yaw(), v.pitch());
        } else {
            // Камера сущности (вид «глазами»): положение и взгляд уже выставила игра — добавляем только осмотр.
            setRotation(getYaw() + v.yaw(), Math.max(-90f, Math.min(90f, getPitch() + v.pitch())));
        }
    }
}
