#version 150

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

// Params: x = серость (0..1), y = затемнение, z = пикселизация (1 = нет), w = виньетка
// Tint:   rgb = множитель цвета, a = сила тонировки
layout(std140) uniform FeedConfig {
    vec4 Params;
    vec4 Tint;
    vec4 Weak;
};

in vec2 texCoord;

out vec4 fragColor;

// Weak.x = степень слабого сигнала (0..1): сдвиг строк, разрывы, цветовое расслоение, размытие, зерно
float hash11(float n) { return fract(sin(n * 91.3458) * 47453.5453); }

vec2 warpUV(vec2 uv) {
    float a = Weak.x;
    if (a <= 0.001) return uv;
    float rows = mix(48.0, 200.0, a);
    float row = floor(uv.y * rows);
    float tear = step(0.86 - 0.35 * a, hash11(row));
    float jitter = tear * (hash11(row + 3.7) - 0.5) * 0.14 * a;
    float wave = sin(uv.y * 38.0 + a * 5.0) * 0.007 * a;
    return vec2(uv.x + jitter + wave, uv.y);
}

vec3 sampleWeak(vec2 uv) {
    float a = Weak.x;
    if (a <= 0.001) return texture(InSampler, uv).rgb;
    vec2 p = warpUV(uv);
    float split = 0.014 * a;
    float blur = 0.004 * a;
    vec3 c = vec3(0.0);
    for (int i = -2; i <= 2; i++) {
        float o = float(i) * blur;
        c.r += texture(InSampler, p + vec2(o + split, 0.0)).r;
        c.g += texture(InSampler, p + vec2(o, 0.0)).g;
        c.b += texture(InSampler, p + vec2(o - split, 0.0)).b;
    }
    c /= 5.0;
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(c, vec3(l), 0.35 * a);
    float n = fract(sin(dot(uv * InSize, vec2(12.9898, 78.233))) * 43758.5453);
    c += (n - 0.5) * 0.22 * a;
    return clamp(c * (1.0 - 0.25 * a), 0.0, 1.0);
}

void main() {
    vec2 uv = texCoord;
    if (Params.z < 0.999) {
        float cells = mix(96.0, InSize.x, Params.z);
        vec2 block = vec2(cells, cells * InSize.y / InSize.x);
        uv = (floor(uv * block) + 0.5) / block;
    }
    vec3 c = sampleWeak(uv);
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(c, vec3(l), Params.x);
    c = mix(c, c * Tint.rgb, Tint.a);
    c *= 1.0 - Params.y;
    float d = distance(texCoord, vec2(0.5));
    c *= 1.0 - Params.w * smoothstep(0.35, 0.9, d);
    fragColor = vec4(c, 1.0);
}
