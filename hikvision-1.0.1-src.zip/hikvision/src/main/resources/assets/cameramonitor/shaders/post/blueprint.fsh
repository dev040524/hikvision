#version 150

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

// Params: x = сила линий, y = затемнение, w = виньетка; Tint.rgb = цвет «синьки»
layout(std140) uniform FeedConfig {
    vec4 Params;
    vec4 Tint;
    vec4 Weak;
};

in vec2 texCoord;
out vec4 fragColor;

// Weak.x = степень слабого сигнала (0..1): сдвиг строк, разрывы, цветовое расслоение, размытие, зерно
float hash11(float n) { return fract(sin(n * 91.3458) * 47453.5453); }

vec2 warpUV(vec2 uv) {
    float a = Weak.x;
    if (a <= 0.001) return uv;
    float rows = mix(48.0, 200.0, a);
    float row = floor(uv.y * rows);
    float tear = step(0.86 - 0.35 * a, hash11(row));
    float jitter = tear * (hash11(row + 3.7) - 0.5) * 0.14 * a;
    float wave = sin(uv.y * 38.0 + a * 5.0) * 0.007 * a;
    return vec2(uv.x + jitter + wave, uv.y);
}

vec3 sampleWeak(vec2 uv) {
    float a = Weak.x;
    if (a <= 0.001) return texture(InSampler, uv).rgb;
    vec2 p = warpUV(uv);
    float split = 0.014 * a;
    float blur = 0.004 * a;
    vec3 c = vec3(0.0);
    for (int i = -2; i <= 2; i++) {
        float o = float(i) * blur;
        c.r += texture(InSampler, p + vec2(o + split, 0.0)).r;
        c.g += texture(InSampler, p + vec2(o, 0.0)).g;
        c.b += texture(InSampler, p + vec2(o - split, 0.0)).b;
    }
    c /= 5.0;
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(c, vec3(l), 0.35 * a);
    float n = fract(sin(dot(uv * InSize, vec2(12.9898, 78.233))) * 43758.5453);
    c += (n - 0.5) * 0.22 * a;
    return clamp(c * (1.0 - 0.25 * a), 0.0, 1.0);
}

float lum(vec2 uv) {
    return dot(texture(InSampler, warpUV(uv)).rgb, vec3(0.299, 0.587, 0.114));
}

void main() {
    vec2 px = 1.5 / InSize;
    float a = lum(texCoord + vec2(-px.x, -px.y));
    float b = lum(texCoord + vec2(0.0, -px.y));
    float c = lum(texCoord + vec2(px.x, -px.y));
    float d = lum(texCoord + vec2(-px.x, 0.0));
    float f = lum(texCoord + vec2(px.x, 0.0));
    float g = lum(texCoord + vec2(-px.x, px.y));
    float h = lum(texCoord + vec2(0.0, px.y));
    float i = lum(texCoord + vec2(px.x, px.y));
    float gx = -a - 2.0 * d - g + c + 2.0 * f + i;
    float gy = -a - 2.0 * b - c + g + 2.0 * h + i;
    float e = clamp(length(vec2(gx, gy)) * Params.x, 0.0, 1.0);
    float base = lum(texCoord);
    vec3 bg = Tint.rgb * (0.5 + 0.5 * base);
    vec3 o = mix(bg, vec3(0.92, 0.97, 1.0), e) * (1.0 - Params.y);
    float dist = distance(texCoord, vec2(0.5));
    o *= 1.0 - Params.w * smoothstep(0.4, 0.95, dist);
    fragColor = vec4(o, 1.0);
}
