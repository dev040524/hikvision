package com.cameramonitor;

import net.minecraft.text.Text;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * История чата для окна камеры. Ванильный чат скрыт вместе с интерфейсом игры, поэтому мод сам запоминает
 * входящие сообщения (игроков и системные) и показывает их поверх картинки.
 */
public final class ChatLog {
    public record Line(Text text, long time) {}

    private static final Deque<Line> LINES = new ArrayDeque<>();

    private ChatLog() {}

    public static void add(Text t) {
        if (t == null) return;
        LINES.addLast(new Line(t, System.currentTimeMillis()));
        while (LINES.size() > 120) LINES.removeFirst();
    }

    public static List<Line> snapshot() { return new ArrayList<>(LINES); }

    public static void clear() { LINES.clear(); }
}
