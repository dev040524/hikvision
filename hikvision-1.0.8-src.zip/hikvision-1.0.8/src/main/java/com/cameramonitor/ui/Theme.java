package com.cameramonitor.ui;

import com.cameramonitor.ModConfig;
import net.minecraft.text.Text;

import java.util.List;

/**
 * Тема оформления. Фон у всех тем прозрачный: панели полупрозрачные,
 * а tint/scan/noise/glitch описывают эффекты поверх изображения камеры.
 */
public record Theme(String id, int panel, int panelAlt, int accent, int accentText, int text, int dim,
                    int border, int good, int bad, int tint, int scan, float noise, float glitch,
                    float flicker, boolean square, int glow) {

    public static final List<Theme> ALL = List.of(
            // Classic Surveillance — зелёный монохром, полосы, пиксельные рамки
            new Theme("classic", 0xB0061208, 0xB00C2410, 0xFF33FF66, 0xFF021006, 0xFF7DFF9B, 0xFF3C9A57,
                    0xFF1E7A3A, 0xFF33FF66, 0xFFFF4D4D, 0x4A0B3D14, 0x38, 0.30f, 0.10f, 0.50f, true, 0),
            // Night Shift — почти чёрный, тёмно-красные индикаторы, аварийная подсветка
            new Theme("night", 0xB4080303, 0xB4140606, 0xFFD01818, 0xFFFFFFFF, 0xFFE8B4B4, 0xFF8A4A4A,
                    0xFF5A1010, 0xFFFFB03D, 0xFFFF2A2A, 0x40280000, 0x1C, 0.12f, 0.05f, 0.25f, false, 0x30FF0000),
            // Analog Tape — янтарь и коричневый, шум плёнки, метки времени
            new Theme("tape", 0xB02A1A0C, 0xB0402A14, 0xFFFFB000, 0xFF2A1800, 0xFFFFD58A, 0xFFB08040,
                    0xFF7A5020, 0xFFC8E060, 0xFFFF6040, 0x48603A00, 0x20, 0.40f, 0.25f, 0.20f, false, 0),
            // Cyber Surveillance — графит, бирюзовые линии, сетка, свечение
            new Theme("cyber", 0xB0121A1F, 0xB01C2830, 0xFF20E3D0, 0xFF04201E, 0xFFD8FFFA, 0xFF6FA8A2,
                    0xFF1F5E5A, 0xFF3CF0A0, 0xFFFF5577, 0x1000E0D0, 0x00, 0.03f, 0f, 0f, false, 0x4020E3D0),
            // Tactical — оливковый, прицел, координаты, строгие панели
            new Theme("tactical", 0xB0161A0E, 0xB0222812, 0xFFA8B84A, 0xFF14180A, 0xFFDCE2B8, 0xFF8A9060,
                    0xFF4E5A2A, 0xFFB8D060, 0xFFE05040, 0x30404A1A, 0x12, 0.08f, 0f, 0f, true, 0),
            // VHS Horror — ч/б, сильный шум, помехи, нестабильное время
            new Theme("vhs", 0xB0101010, 0xB01C1C1C, 0xFFF0F0F0, 0xFF000000, 0xFFE0E0E0, 0xFF808080,
                    0xFF505050, 0xFFFFFFFF, 0xFFFF2020, 0x90808080, 0x30, 0.75f, 0.80f, 0.60f, true, 0),
            // Ghost Signal — полупрозрачные чёрные панели, градиенты, слабое зелёное свечение
            new Theme("ghost", 0x70000000, 0x80060A06, 0xFF4DFF88, 0xFF001208, 0xFFCFEFD8, 0xFF6E8E78,
                    0x602A7A48, 0xFF4DFF88, 0xFFFF6060, 0x1A001A08, 0x00, 0.04f, 0.02f, 0f, false, 0x384DFF88)            ,
            // Neon Noir — пурпур и бирюза на чёрном, неоновое свечение
            new Theme("neon", 0xB0100818, 0xB01C0C2C, 0xFFFF2BD6, 0xFF14001A, 0xFFF3D9FF, 0xFF9C6FBF,
                    0xFF5B1F7A, 0xFF2BFFD0, 0xFFFF4D6D, 0x30301060, 0x14, 0.05f, 0.08f, 0.15f, false, 0x50FF2BD6),
            // Pixel 8-bit — крупные пиксели, постеризация, игровой HUD
            new Theme("pixel", 0xB0101820, 0xB01C2A38, 0xFFFFD83A, 0xFF201800, 0xFFF0F0F0, 0xFF8090A0,
                    0xFF3A506A, 0xFF58E060, 0xFFFF4040, 0x00000000, 0x00, 0f, 0f, 0.10f, true, 0)

    
            ,
            // Terminal 1999 — старый терминал: зелёный моноширинный текст, мигающий курсор, пиксельные панели
            new Theme("terminal", 0xB0020A02, 0xB0041A06, 0xFF2BFF4A, 0xFF001A04, 0xFF8CFF9C, 0xFF2F9A44,
                    0xFF1B7A2E, 0xFF2BFF4A, 0xFFFF5A3A, 0x38061A08, 0x30, 0.12f, 0.04f, 0.35f, true, 0x302BFF4A)
            ,
            // Deep Ocean — глубокий тёмно-синий, холодное голубое свечение, подводное наблюдение
            new Theme("deep", 0xB0031428, 0xB00A2540, 0xFF4FD8FF, 0xFF02121E, 0xFFCFEFFF, 0xFF5E93B5,
                    0xFF14507A, 0xFF3CF0C8, 0xFFFF6A7A, 0x30083A6A, 0x00, 0.06f, 0.03f, 0.05f, false, 0x404FD8FF),
            // Liminal — пустые помещения: выцветшие цвета, слабый шум, размытые границы, чувство наблюдения
            new Theme("liminal", 0xB02B2A22, 0xB03A382C, 0xFFD9D4A8, 0xFF2B2A22, 0xFFE6E2C8, 0xFF9A9678,
                    0xFF5E5C48, 0xFFB8D49A, 0xFFE08A6A, 0x30C8B870, 0x08, 0.10f, 0.00f, 0.15f, false, 0x20E6E2C8));

    public static Theme byId(String id) {
        for (Theme t : ALL) if (t.id.equals(id)) return t;
        return ALL.get(0);
    }

    public static Theme current() {
        return byId(ModConfig.get().theme);
    }

    public static Theme next(String id) {
        int i = ALL.indexOf(byId(id));
        return ALL.get((i + 1) % ALL.size());
    }

    public static Theme prev(String id) {
        int i = ALL.indexOf(byId(id));
        return ALL.get((i - 1 + ALL.size()) % ALL.size());
    }

    /** Фон интерфейса: затемнённый оттенок панели с непрозрачностью из настроек. */
    public int bg() {
        int a = (int) Math.round(ModConfig.get().backgroundOpacity * 255);
        int p = panel | 0xFF000000;
        float lum = (((p >> 16) & 0xFF) * 0.299f + ((p >> 8) & 0xFF) * 0.587f + (p & 0xFF) * 0.114f) / 255f;
        int dark = UiUtil.mix(p, 0xFF000000, lum > 0.6f ? 0.12f : 0.45f) & 0xFFFFFF; // светлые темы остаются светлыми
        return (a << 24) | dark;
    }

    public Text label() {
        return Text.translatable("cameramonitor.theme." + id);
    }
}
