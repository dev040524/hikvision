package com.cameramonitor.ui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

/**
 * Оформление изображения камеры: наложения поверх уже отрисованного мира.
 * Настоящих шейдеров нет (клиентский мод без ресурсов шейдеров), поэтому «ч/б» и «монохром»
 * имитируются полупрозрачной тонировкой, шумом и полосами.
 */
public final class FeedEffects {
    public record Info(String name, double x, double y, double z, float yaw, float pitch, String src) {}

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private FeedEffects() {}

    public static void draw(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, boolean shaderOn) {
        long now = System.currentTimeMillis();
        // Если включён шейдер, серость и тонировка уже применены к миру — накладываем только шум и графику.
        if (!shaderOn && (t.tint() >>> 24) > 0) g.fill(x, y, x + w, y + h, t.tint());
        if (t.scan() > 0) for (int yy = y; yy < y + h; yy += 3) g.fill(x, yy, x + w, yy + 1, t.scan() << 24);
        noise(g, t, x, y, w, h, now);
        glitch(g, t, x, y, w, h, now);
        switch (t.id()) {
            case "classic" -> classic(g, tr, t, x, y, w, h, i, now);
            case "night" -> night(g, tr, t, x, y, w, h, i, now);
            case "tape" -> tape(g, tr, t, x, y, w, h, i, now);
            case "cyber" -> cyber(g, tr, t, x, y, w, h, i, now);
            case "tactical" -> tactical(g, tr, t, x, y, w, h, i, now);
            case "vhs" -> vhs(g, tr, t, x, y, w, h, i, now);
            case "ghost" -> ghost(g, tr, t, x, y, w, h, i, now);
            case "neon" -> neon(g, tr, t, x, y, w, h, i, now);
            case "pixel" -> pixel(g, tr, t, x, y, w, h, i, now);
            case "terminal" -> terminal(g, tr, t, x, y, w, h, i, now);
            case "deep" -> deep(g, tr, t, x, y, w, h, i, now);
            case "liminal" -> liminal(g, tr, t, x, y, w, h, i, now);
            default -> { }
        }
    }

    /** Рамка вокруг области изображения: толщина/свечение зависят от темы. */
    public static void frame(DrawContext g, Theme t, int x, int y, int w, int h) {
        if (t.glow() != 0) {
            int ga = t.glow() >>> 24;
            for (int k = 1; k <= 4; k++)
                UiUtil.outline(g, x - 1 - k, y - 1 - k, w + 2 + 2 * k, h + 2 + 2 * k, ((ga / (k + 1)) << 24) | (t.glow() & 0xFFFFFF));
        }
        UiUtil.outline(g, x - 1, y - 1, w + 2, h + 2, t.accent());
        if (t.square()) UiUtil.outline(g, x - 2, y - 2, w + 4, h + 4, t.border());
    }

    /** Заставка «нет сигнала»: плотный шум, бегущие полосы и мигающая надпись. */
    public static void noSignal(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, String title, String sub) {
        long now = System.currentTimeMillis();
        g.fill(x, y, x + w, y + h, 0xFF07090C);
        Random r = new Random(now / 60);
        int n = w * h / 220;
        for (int k = 0; k < n; k++) {
            int px = x + r.nextInt(Math.max(1, w - 4)), py = y + r.nextInt(Math.max(1, h - 2));
            int gr = 40 + r.nextInt(150);
            g.fill(px, py, px + 1 + r.nextInt(4), py + 1 + r.nextInt(2), 0xFF000000 | gr << 16 | gr << 8 | gr);
        }
        for (int k = 0; k < 2; k++) {
            int by = y + (int) ((now / (5 + 3 * k)) % (h + 60)) - 30;
            int y1 = Math.max(y, by), y2 = Math.min(y + h, by + 22);
            if (y2 > y1) g.fillGradient(x, y1, x + w, y2, 0x00FFFFFF, 0x38FFFFFF);
        }
        for (int yy = y; yy < y + h; yy += 3) g.fill(x, yy, x + w, yy + 1, 0x30000000);
        int cx = x + w / 2, cy = y + h / 2;
        int bw = Math.max(tr.getWidth(title), tr.getWidth(sub)) + 24;
        g.fill(cx - bw / 2, cy - 22, cx + bw / 2, cy + 20, 0xB0000000);
        UiUtil.outline(g, cx - bw / 2, cy - 22, bw, 42, t.dim());
        int tc = (now / 500) % 2 == 0 ? t.bad() : (t.bad() & 0xFFFFFF) | 0x66000000;
        g.drawText(tr, title, cx - tr.getWidth(title) / 2, cy - 12, tc, true);
        g.drawText(tr, sub, cx - tr.getWidth(sub) / 2, cy + 3, 0xFFB0B8C4, false);
    }


    /**
     * Слабый сигнал (amount 0..1). Всё движется непрерывно по времени, а не сменой кадров: полосы плывут,
     * разрывы дрейфуют и пульсируют, зерно обновляется каждый кадр. Основное искажение картинки делает шейдер.
     */
    public static void interference(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, float amount, long now) {
        java.util.concurrent.ThreadLocalRandom r = java.util.concurrent.ThreadLocalRandom.current();
        // Зерно: у настоящих помех оно новое в каждом кадре.
        int n = (int) (amount * w * h / 220f);
        for (int k = 0; k < n; k++) {
            int px = x + r.nextInt(Math.max(1, w - 3)), py = y + r.nextInt(Math.max(1, h - 1));
            int a = 0x28 + r.nextInt(0x50);
            g.fill(px, py, px + 1 + r.nextInt(3), py + 1, (a << 24) | (r.nextBoolean() ? 0xFFFFFF : 0));
        }
        // Широкие светлые полосы плавно ползут сверху вниз; скорость растёт с помехами.
        double speed = 0.04 + 0.10 * amount;
        for (int k = 0; k < 2; k++) {
            double ph = ((now * speed * (k == 0 ? 1.0 : -0.6)) % (h + 80) + (h + 80)) % (h + 80);
            int by = y + (int) ph - 40;
            int y1 = Math.max(y, by), y2 = Math.min(y + h, by + 26 + (int) (amount * 18));
            if (y2 > y1) g.fillGradient(x, y1, x + w, y2, 0x00FFFFFF, ((int) (0x14 + amount * 0x30) << 24) | 0xFFFFFF);
        }
        // Строки с разрывом: дрейфуют вниз, длина и яркость плавно пульсируют.
        int bars = 1 + (int) (amount * 6);
        for (int k = 0; k < bars; k++) {
            double ph = ((now * (0.02 + 0.015 * k) + k * h / (double) bars) % h + h) % h;
            int by = y + (int) ph;
            double pulse = 0.5 + 0.5 * Math.sin(now / (260.0 + 70 * k) + k);
            int len = (int) (w * (0.25 + 0.7 * pulse * amount));
            int off = (int) ((Math.sin(now / 900.0 + k * 1.7) * 0.5 + 0.5) * (w - len));
            int th = 1 + (int) (amount * 3 * pulse);
            g.fill(x + off, by, x + off + len, by + th, ((int) (0x20 + 0x40 * pulse * amount) << 24) | 0xFFFFFF);
            if (amount > 0.6f) g.fill(x + off, by + th, x + off + len, by + th + 1, 0x70000000);
        }
        // Редкие кратковременные «выпадения» строк, чаще при сильных помехах.
        if (r.nextFloat() < amount * amount * 0.20f) {
            int by = y + r.nextInt(Math.max(1, h - 12));
            g.fill(x, by, x + w, by + 2 + r.nextInt(8), 0xC0000000);
        }
        // Потемнение к краям растёт с расстоянием.
        int edge = (int) (amount * 0x70);
        g.fillGradient(x, y, x + w, y + h / 4, edge << 24, 0x00000000);
        g.fillGradient(x, y + h * 3 / 4, x + w, y + h, 0x00000000, edge << 24);

        int lit = 1 + (int) ((1f - amount) * 3f);
        int bx = x + w / 2 - 22, by2 = y + 34;
        for (int k = 0; k < 4; k++) {
            int bh = 4 + k * 3;
            g.fill(bx + k * 6, by2 + 13 - bh, bx + k * 6 + 4, by2 + 13, k < lit ? t.good() : 0x60FFFFFF);
        }
        if ((now / 450) % 2 == 0) g.drawText(tr, "WEAK SIGNAL", bx + 28, by2 + 3, t.bad(), true);
    }

    // ---------------------------------------------------------------- общие эффекты

    private static void noise(DrawContext g, Theme t, int x, int y, int w, int h, long now) {
        int n = (int) (t.noise() * w * h / 500f);
        Random r = new Random(now / 70);
        for (int k = 0; k < n; k++) {
            int px = x + r.nextInt(Math.max(1, w - 3)), py = y + r.nextInt(Math.max(1, h - 1));
            int a = 0x30 + r.nextInt(0x70);
            int v = r.nextBoolean() ? 0xFFFFFF : 0;
            g.fill(px, py, px + 1 + r.nextInt(3), py + 1, (a << 24) | v);
        }
    }

    private static void glitch(DrawContext g, Theme t, int x, int y, int w, int h, long now) {
        if (t.glitch() <= 0) return;
        Random r = new Random(now / 50);
        if (now % 5000 < (long) (500 * t.glitch())) {
            g.fill(x, y, x + w, y + h, 0x14FFFFFF);
            int bars = 2 + (int) (6 * t.glitch());
            for (int k = 0; k < bars; k++) {
                int by = y + r.nextInt(Math.max(1, h - 12)), bh = 2 + r.nextInt(10);
                g.fill(x, by, x + w, by + bh, 0x40FFFFFF);
                g.fill(x + r.nextInt(w / 4 + 1), by, x + w, by + 1, 0x90000000);
            }
        }
        if (t.glitch() >= 0.25f) { // «трекинг» — бегущая светлая полоса
            int by = y + (int) ((now / 8) % (h + 40)) - 20;
            int y1 = Math.max(y, by), y2 = Math.min(y + h, by + 14);
            if (y2 > y1) g.fillGradient(x, y1, x + w, y2, 0x00FFFFFF, 0x30FFFFFF);
        }
    }

    private static int flick(Theme t, long now, int color) {
        if (t.flicker() > 0 && new Random(now / 90).nextFloat() < t.flicker() * 0.25f)
            return (color & 0xFFFFFF) | 0x66000000;
        return color;
    }

    private static void text(DrawContext g, TextRenderer tr, String s, int x, int y, int color) {
        if (Theme.current().id().equals("terminal")) UiUtil.mono(g, tr, s, x, y, color, true);
        else g.drawText(tr, s, x, y, color, true);
    }

    private static void textR(DrawContext g, TextRenderer tr, String s, int right, int y, int color) {
        if (Theme.current().id().equals("terminal")) UiUtil.mono(g, tr, s, right - s.length() * UiUtil.MONO_W, y, color, true);
        else g.drawText(tr, s, right - tr.getWidth(s), y, color, true);
    }

    private static void recDot(DrawContext g, int x, int y, int color, long now, long period) {
        if ((now / period) % 2 == 0) g.fill(x, y, x + 6, y + 6, color);
    }

    private static void brackets(DrawContext g, int x, int y, int w, int h, int len, int c) {
        g.fill(x, y, x + len, y + 2, c); g.fill(x, y, x + 2, y + len, c);
        g.fill(x + w - len, y, x + w, y + 2, c); g.fill(x + w - 2, y, x + w, y + len, c);
        g.fill(x, y + h - 2, x + len, y + h, c); g.fill(x, y + h - len, x + 2, y + h, c);
        g.fill(x + w - len, y + h - 2, x + w, y + h, c); g.fill(x + w - 2, y + h - len, x + w, y + h, c);
    }

    private static String stamp() { return LocalDateTime.now().format(TS); }

    private static int heading(float yaw) { return (((int) (yaw + 180f)) % 360 + 360) % 360; }

    // ---------------------------------------------------------------- темы

    private static void classic(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        brackets(g, x + 6, y + 6, w - 12, h - 12, 16, t.accent());
        recDot(g, x + 16, y + 17, 0xFFFF3030, now, 600);
        text(g, tr, "CAM  " + i.name(), x + 28, y + 16, flick(t, now, t.text()));
        text(g, tr, stamp(), x + 16, y + h - 24, flick(t, now + 90, t.accent()));
        textR(g, tr, "SRC:" + i.src(), x + w - 16, y + 16, t.dim());
    }

    private static void night(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        int pulse = (int) ((Math.sin(now / 700.0) + 1) * 0.5 * 0x38);
        int c = ((0x18 + pulse) << 24) | 0xC00000;
        g.fillGradient(x, y, x + w, y + 34, c, 0x00C00000);
        g.fillGradient(x, y + h - 34, x + w, y + h, 0x00C00000, c);
        recDot(g, x + 14, y + 14, t.bad(), now, 900);
        text(g, tr, i.name(), x + 26, y + 13, flick(t, now, t.text()));
        text(g, tr, stamp(), x + 14, y + h - 22, t.dim());
        textR(g, tr, "NIGHT", x + w - 14, y + 13, t.accent());
    }

    private static void tape(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        Random r = new Random(now / 90);
        if (r.nextInt(5) == 0) { // царапина плёнки
            int sx = x + r.nextInt(w), sh = 6 + r.nextInt(30);
            g.fill(sx, y + r.nextInt(Math.max(1, h - sh)), sx + 1, y + h, 0x30FFFFFF);
        }
        long sec = (now / 1000) % 3600;
        text(g, tr, "▶ PLAY", x + 14, y + 14, flick(t, now, t.accent()));
        textR(g, tr, "SP", x + w - 14, y + 14, t.accent());
        text(g, tr, i.name(), x + 14, y + 26, t.text());
        text(g, tr, String.format("00:%02d:%02d   %s", sec / 60, sec % 60, stamp()), x + 14, y + h - 22, t.text());
    }

    private static void cyber(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        int grid = 0x14000000 | (t.accent() & 0xFFFFFF);
        for (int gx = x + 32; gx < x + w; gx += 32) g.fill(gx, y, gx + 1, y + h, grid);
        for (int gy = y + 32; gy < y + h; gy += 32) g.fill(x, gy, x + w, gy + 1, grid);
        brackets(g, x + 8, y + 8, w - 16, h - 16, 12, t.accent());
        int sweep = x + (int) ((now / 12) % Math.max(1, w));
        g.fill(sweep, y, sweep + 1, y + h, 0x2020E3D0);
        text(g, tr, "◉ " + i.name(), x + 18, y + 18, t.accent());
        text(g, tr, String.format("%.0f %.0f %.0f", i.x(), i.y(), i.z()), x + 18, y + h - 24, t.text());
        textR(g, tr, i.src(), x + w - 18, y + 18, t.dim());
    }

    private static void tactical(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        int a = t.accent(), cx = x + w / 2, cy = y + h / 2;
        g.fill(cx - 22, cy, cx - 6, cy + 1, a); g.fill(cx + 6, cy, cx + 22, cy + 1, a);
        g.fill(cx, cy - 22, cx + 1, cy - 6, a); g.fill(cx, cy + 6, cx + 1, cy + 22, a);
        g.fill(cx, cy, cx + 1, cy + 1, 0xFFFF4030);
        brackets(g, cx - 36, cy - 36, 72, 72, 8, a);
        int tick = 0x90000000 | (a & 0xFFFFFF);
        for (int k = 0, tx = x + 16; tx < x + w - 8; tx += 16, k++) {
            int len = k % 4 == 0 ? 8 : 4;
            g.fill(tx, y, tx + 1, y + len, tick);
            g.fill(tx, y + h - len, tx + 1, y + h, tick);
        }
        text(g, tr, "CAM // " + i.name().toUpperCase(), x + 14, y + 14, t.text());
        textR(g, tr, "SRC " + i.src(), x + w - 14, y + 14, a);
        text(g, tr, String.format("HDG %03d  PIT %+d", heading(i.yaw()), (int) i.pitch()), x + 14, y + h - 24, a);
        textR(g, tr, String.format("X%.0f Y%.0f Z%.0f", i.x(), i.y(), i.z()), x + w - 14, y + h - 24, t.text());
    }

    private static void vhs(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        Random r = new Random(now / 110);
        char[] ts = stamp().toCharArray();
        if (r.nextFloat() < 0.5f)
            for (int k = 0; k < 2; k++) {
                int p = r.nextInt(ts.length);
                if (Character.isDigit(ts[p])) ts[p] = (char) ('0' + r.nextInt(10));
            }
        int jx = r.nextInt(100) < 15 ? r.nextInt(5) - 2 : 0;
        text(g, tr, "PLAY ▶", x + 16, y + 16, flick(t, now, 0xFFFFFFFF));
        textR(g, tr, "SP  " + i.name(), x + w - 16, y + 16, t.text());
        text(g, tr, new String(ts), x + 16 + jx, y + h - 26, flick(t, now + 40, 0xFFFFFFFF));
        recDot(g, x + w - 28, y + h - 26, t.bad(), now, 500);
    }

    private static void ghost(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        g.fillGradient(x, y, x + w, y + h / 3, 0x80000000, 0x00000000);
        g.fillGradient(x, y + h * 2 / 3, x + w, y + h, 0x00000000, 0x90000000);
        text(g, tr, i.name(), x + 16, y + h - 24, 0xB0CFEFD8);
        if ((now / 1400) % 2 == 0) g.fill(x + 16, y + 16, x + 20, y + 20, 0xA04DFF88);
    }

    // ---------------------------------------------------------------- новые темы

    private static void neon(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        int a = t.accent();
        int pulse = 0x60 + (int) ((Math.sin(now / 450.0) + 1) * 0x28);
        int sweep = x + (int) ((now / 9) % Math.max(1, w));
        g.fill(sweep, y, sweep + 1, y + h, 0x30FF2BD6);
        g.fill(sweep - 3, y, sweep, y + h, 0x10FF2BD6);
        brackets(g, x + 8, y + 8, w - 16, h - 16, 18, (pulse << 24) | (a & 0xFFFFFF));
        brackets(g, x + 9, y + 9, w - 18, h - 18, 18, 0x302BFFD0);
        String name = "▌" + i.name();
        g.drawText(tr, name, x + 19, y + 17, 0x60FF2BD6, false);
        g.drawText(tr, name, x + 17, y + 15, 0x602BFFD0, false);
        text(g, tr, name, x + 18, y + 16, flick(t, now, 0xFFFFE6FA));
        textR(g, tr, "● LIVE", x + w - 18, y + 16, t.good());
        text(g, tr, stamp(), x + 18, y + h - 24, t.dim());
    }

    private static void pixel(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        int a = t.accent();
        for (int cx : new int[]{x + 4, x + w - 10}) for (int cy : new int[]{y + 4, y + h - 10}) g.fill(cx, cy, cx + 6, cy + 6, a);
        text(g, tr, "1UP  " + i.name().toUpperCase(), x + 16, y + 14, a);
        long sec = (now / 1000) % 86400;
        text(g, tr, String.format("TIME %02d:%02d:%02d", sec / 3600, sec / 60 % 60, sec % 60), x + 16, y + h - 24, t.text());
        int lit = 4 + ((now / 700) % 4 == 0 ? 0 : 1);
        text(g, tr, "SIGNAL", x + w - 16 - 5 * 9 - tr.getWidth("SIGNAL") - 6, y + 14, t.text());
        for (int k = 0; k < 5; k++)
            g.fill(x + w - 16 - (5 - k) * 9, y + 14, x + w - 16 - (5 - k) * 9 + 7, y + 22, k < lit ? t.good() : 0x60FFFFFF);
    }


    /** Deep Ocean: лучи света сверху, «морской снег», пузыри, глубиномер. Редкие помехи даёт общий эффект темы. */
    private static void deep(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        for (int k = 0; k < 4; k++) {
            int bw = 26 + k * 14;
            int bx = x + (int) ((0.15 + 0.2 * k) * w + Math.sin(now / 4200.0 + k * 1.7) * 38);
            int a0 = 0x1C - k * 3;
            g.fillGradient(Math.max(x, bx), y, Math.min(x + w, bx + bw), y + (int) (h * 0.85), (a0 << 24) | 0x9FE8FF, 0x009FE8FF);
        }
        for (int k = 0; k < 46; k++) { // морской снег
            Random r = new Random(k * 6151L);
            int px = x + r.nextInt(Math.max(1, w));
            double spd = 6 + r.nextInt(14);
            int py = y + (int) (((r.nextInt(Math.max(1, h)) + now * spd / 1000.0) % h));
            int a = 0x22 + r.nextInt(0x40);
            g.fill(px + (int) (Math.sin(now / 1500.0 + k) * 3), py, px + 1 + r.nextInt(2), py + 1 + r.nextInt(2), (a << 24) | 0xCFEFFF);
        }
        for (int k = 0; k < 7; k++) { // пузыри поднимаются
            Random r = new Random(k * 977L + 5);
            double spd = 22 + r.nextInt(22);
            int by = y + h - (int) (((now * spd / 1000.0) + r.nextInt(Math.max(1, h))) % (h + 30));
            int bx = x + 20 + r.nextInt(Math.max(1, w - 40)) + (int) (Math.sin(now / 700.0 + k) * 6);
            int rad = 2 + r.nextInt(3);
            UiUtil.outline(g, bx - rad, by - rad, rad * 2 + 1, rad * 2 + 1, 0x60CFEFFF);
            g.fill(bx - rad + 1, by - rad + 1, bx - rad + 2, by - rad + 2, 0x90FFFFFF);
        }
        g.fillGradient(x, y + h - 60, x + w, y + h, 0x00031428, 0x70031428); // толща воды внизу темнее
        int depth = (int) Math.max(0, 63 - i.y());
        text(g, tr, "◉ SUBSEA  " + i.name(), x + 16, y + 14, flick(t, now, t.text()));
        text(g, tr, String.format("DEPTH %d M   %.1f BAR", depth, 1.0 + depth / 10.0), x + 16, y + 26, t.accent());
        textR(g, tr, "SONAR " + ((now / 1000) % 2 == 0 ? "PING" : "----"), x + w - 16, y + 14, t.dim());
        text(g, tr, stamp(), x + 16, y + h - 22, t.dim());
    }

    /** Liminal: выцветшая пустота, мягкие размытые края, гул ламп, тихое «за вами наблюдают». */
    private static void liminal(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        // размытые границы: плавное затухание к краям со всех сторон
        for (int k = 0; k < 28; k++) {
            int a = (int) (0x60 * Math.pow(1.0 - k / 28.0, 2));
            int c = (a << 24) | 0x1E1C10;
            g.fill(x + k, y, x + k + 1, y + h, c);
            g.fill(x + w - k - 1, y, x + w - k, y + h, c);
        }
        g.fillGradient(x, y, x + w, y + 34, 0x601E1C10, 0x001E1C10);
        g.fillGradient(x, y + h - 34, x + w, y + h, 0x001E1C10, 0x601E1C10);
        // гул люминесцентных ламп: медленная широкая полоса и редкие провалы яркости
        int by = y + (int) ((now / 40) % (h + 100)) - 50;
        int y1 = Math.max(y, by), y2 = Math.min(y + h, by + 90);
        if (y2 > y1) g.fillGradient(x, y1, x + w, y2, 0x00FFF6D0, 0x0CFFF6D0);
        if ((now / 70) % 113 == 0 || (now / 70) % 127 == 1) g.fill(x, y, x + w, y + h, 0x18000000);
        text(g, tr, "LEVEL 0  ·  " + i.name(), x + 16, y + 14, flick(t, now, t.dim()));
        text(g, tr, stamp().substring(11), x + 16, y + h - 22, t.dim());
        boolean eye = (now / 1700) % 2 == 0;
        textR(g, tr, (eye ? "● " : "○ ") + "OBSERVED", x + w - 16, y + h - 22, eye ? t.text() : t.dim());
    }

    /** Terminal 1999: моноширинный зелёный текст, журнал сигнала, мигающий курсор, пиксельные углы. */
    private static void terminal(DrawContext g, TextRenderer tr, Theme t, int x, int y, int w, int h, Info i, long now) {
        int a = t.accent(), dim = t.dim();
        for (int cx : new int[]{x + 4, x + w - 10}) for (int cy : new int[]{y + 4, y + h - 10}) g.fill(cx, cy, cx + 6, cy + 6, a);
        boolean cursor = (now / 500) % 2 == 0;
        String name = i.name().toUpperCase();
        text(g, tr, "HIKVISION TERMINAL V1.99", x + 18, y + 14, dim);
        text(g, tr, "> CAM " + name + (cursor ? "_" : " "), x + 18, y + 26, flick(t, now, a));
        long up = (now / 1000) % 100000;
        textR(g, tr, String.format("UPTIME %05d", up), x + w - 18, y + 14, dim);
        textR(g, tr, "CH " + (Math.abs(name.hashCode()) % 90 + 10), x + w - 18, y + 26, dim);

        int ly = y + h - 18 - 5 * 11;
        text(g, tr, "> SIGNAL ........ OK", x + 18, ly, a);
        text(g, tr, "> SRC ........... " + i.src(), x + 18, ly + 11, a);
        text(g, tr, String.format("> POS %.0f %.0f %.0f", i.x(), i.y(), i.z()), x + 18, ly + 22, a);
        text(g, tr, String.format("> HDG %03d PIT %+d", (((int) (i.yaw() + 180f)) % 360 + 360) % 360, (int) i.pitch()), x + 18, ly + 33, a);
        text(g, tr, "> " + stamp() + (cursor ? " _" : "  "), x + 18, ly + 44, flick(t, now + 120, a));
    }
}
