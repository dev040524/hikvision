package com.cameramonitor.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.sound.SoundManager;

import java.util.function.BooleanSupplier;

/**
 * Кнопка в стиле темы. Игра сама рисует подложку кнопки (renderWidget у неё final), поэтому весь внешний вид
 * рисуется в drawIcon поверх неё, а подложка закрывается непрозрачным фоном.
 * Внимание: внутри наследников ButtonWidget имя Text означает вложенный ButtonWidget.Text, поэтому текст указан полностью.
 */
public class ThemedButton extends ButtonWidget {
    private BooleanSupplier toggled = () -> false;
    private boolean danger;

    public ThemedButton(int x, int y, int w, int h, net.minecraft.text.Text label, PressAction action) {
        super(x, y, w, h, label, action, DEFAULT_NARRATION_SUPPLIER);
    }

    public ThemedButton toggled(BooleanSupplier s) { this.toggled = s; return this; }

    public ThemedButton danger() { this.danger = true; return this; }

    public ThemedButton tip(net.minecraft.text.Text t) { setTooltip(Tooltip.of(t)); return this; }

    /** Стандартный «клик» игры отключён — у действий свои звуки. */
    @Override
    public void playDownSound(SoundManager soundManager) {
    }

    @Override
    public void drawIcon(DrawContext g, int mx, int my, float delta) {
        Theme t = Theme.current();
        boolean on = toggled.getAsBoolean();
        boolean hov = isHovered() && active;
        int bg, border, fg;
        if (!active) {
            bg = t.panel(); border = t.border(); fg = t.dim();
        } else if (danger) {
            bg = hov ? t.bad() : UiUtil.mix(t.panelAlt(), t.bad(), 0.35f); border = t.bad(); fg = hov ? 0xFFFFFFFF : t.text();
        } else if (on) {
            bg = t.accent(); border = t.accent(); fg = t.accentText();
        } else {
            bg = hov ? UiUtil.mix(t.panelAlt(), t.accent(), 0.25f) : t.panelAlt();
            border = hov ? t.accent() : t.border();
            fg = t.text();
        }
        g.fill(getX(), getY(), getX() + getWidth(), getY() + getHeight(), 0xFF000000 | (t.bg() & 0xFFFFFF)); // закрываем подложку игры
        UiUtil.rounded(g, getX(), getY(), getWidth(), getHeight(), bg, border);
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        net.minecraft.text.Text m = getMessage();
        if (t.id().equals("terminal")) {
            String ms = m.getString();
            UiUtil.mono(g, tr, ms, getX() + (getWidth() - ms.length() * UiUtil.MONO_W) / 2, getY() + (getHeight() - 8) / 2, fg, false);
        } else {
            g.drawText(tr, m, getX() + (getWidth() - tr.getWidth(m)) / 2, getY() + (getHeight() - 8) / 2, fg, false);
        }
    }
}
