package com.cameramonitor;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

/**
 * Проверка новой версии: раз за запуск спрашивает у GitHub последний релиз
 * (https://github.com/dev040524/hikvision/releases) и, если он новее установленной версии,
 * пишет об этом в чат при входе в мир. Всё в фоновом потоке; без сети проверка тихо пропускается.
 */
public final class UpdateChecker {
    public static final String RELEASES_URL = "https://github.com/dev040524/hikvision/releases";
    private static final String API_URL = "https://api.github.com/repos/dev040524/hikvision/releases/latest";

    private static volatile String latest = "";
    private static volatile boolean checked, newer, notified;

    private UpdateChecker() {}

    public static String current() {
        return FabricLoader.getInstance().getModContainer(CameraMonitorClient.MOD_ID)
                .map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("?");
    }

    public static String latest() { return latest; }
    public static boolean checked() { return checked; }
    public static boolean isNewer() { return newer; }

    public static void checkAsync() {
        if (!ModConfig.get().updateCheck) return;
        Thread t = new Thread(UpdateChecker::check, "hikvision-update-check");
        t.setDaemon(true);
        t.start();
    }

    private static void check() {
        try {
            HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
            HttpRequest req = HttpRequest.newBuilder(URI.create(API_URL))
                    .header("User-Agent", "HIKVision-Minecraft-Mod")
                    .header("Accept", "application/vnd.github+json")
                    .timeout(Duration.ofSeconds(8)).GET().build();
            HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() == 200) {
                JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();
                String tag = o.get("tag_name").getAsString();
                latest = tag.startsWith("v") || tag.startsWith("V") ? tag.substring(1) : tag;
                newer = compare(latest, current()) > 0;
            }
        } catch (Exception e) {
            CameraMonitorClient.LOG.debug("Update check skipped: {}", e.toString());
        } finally {
            checked = true;
        }
    }

    /** Сравнение версий по числам: 1.0.10 новее 1.0.9. */
    static int compare(String a, String b) {
        int[] x = nums(a), y = nums(b);
        for (int i = 0; i < Math.max(x.length, y.length); i++) {
            int p = i < x.length ? x[i] : 0, q = i < y.length ? y[i] : 0;
            if (p != q) return Integer.compare(p, q);
        }
        return 0;
    }

    private static int[] nums(String v) {
        String[] parts = v.replaceAll("[^0-9.]", "").split("\\.");
        int[] r = new int[parts.length];
        for (int i = 0; i < parts.length; i++) {
            try {
                r[i] = parts[i].isEmpty() ? 0 : Integer.parseInt(parts[i]);
            } catch (NumberFormatException e) {
                r[i] = 0;
            }
        }
        return r;
    }

    /** Сообщение в чат при входе в мир (один раз за запуск), если вышла новая версия. */
    public static void onJoin(MinecraftClient client) {
        if (!ModConfig.get().updateCheck || notified) return;
        Thread t = new Thread(() -> {
            for (int i = 0; i < 50 && !checked; i++) { // ждём результат проверки до ~5 с
                try { Thread.sleep(100); } catch (InterruptedException e) { return; }
            }
            if (!newer || notified) return;
            notified = true;
            client.execute(() -> {
                Text msg = Text.literal("[HIKVision] ").formatted(Formatting.AQUA)
                        .append(Text.translatable("cameramonitor.update.chat", latest, current(), RELEASES_URL));
                client.inGameHud.getChatHud().addMessage(msg);
                ChatLog.add(msg);
            });
        }, "hikvision-update-notify");
        t.setDaemon(true);
        t.start();
    }
}
